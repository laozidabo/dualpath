"""Reproducible paired pilot; never send hidden tests/reference solutions to the API."""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import fcntl
import getpass
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor"))
from dualpath import DualPath
from dualpath.llm import LanguageModel
from dualpath.prompts import DIRECT_EXECUTE
from dualpath.search import NoSearch
from evaluate import extract_code, grade

REF = "ff23e7e07db44b2c11fb9d60ec946439958757f6"
CODE_RULE = "\n\n交付要求：最终成果必须是一个完整的 Python 代码块，包含所有必需的标准库导入和指定函数。不要读取标准输入，不要运行演示代码，不要依赖第三方库。只按题目明确的输入范围实现，不需要为未规定的输入补充规则。"
FEEDBACK = "[SELF_FEEDBACK]\n检查候选 Python 实现是否满足任务的每一项明确要求。寻找具体边界情况、反例和实现错误；说明需修改之处。不要为题目未要求的输入引入限制。如果实现已正确，明确说无需修改。"
REWRITE = "[SELF_REWRITE]\n根据任务、候选代码和审查意见，交付完整正确的 Python 实现。审查意见也可能有误，请逐项核对任务再决定是否采纳。仅返回一个完整的 Python 代码块，保留已正确的行为。"


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def tasks():
    result = []
    for path in sorted((ROOT / "bench").glob("tasks_*.jsonl")):
        result.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    result.sort(key=lambda t: t["id"])
    if len(result) != 30 or len({t["id"] for t in result}) != 30:
        raise ValueError(f"Expected 30 unique frozen tasks, got {len(result)}")
    for t in result:
        for k in ("id", "prompt", "reference", "tests", "mutants", "entry_point", "category"):
            if k not in t:
                raise ValueError(f"Missing {k} in {t.get('id')}")
        if not t["mutants"]:
            raise ValueError("Each task needs at least one mutation control")
    return result


def validate():
    ts = tasks()
    rows = []
    for task in ts:
        correct = grade(task["reference"], task["tests"], timeout=8)
        mutations = [{"name": m["name"], "grade": grade(m["code"], task["tests"], timeout=8)} for m in task["mutants"]]
        ok = correct["status"] == "pass" and all(m["grade"]["status"] in {"fail", "timeout"} for m in mutations)
        rows.append({"id": task["id"], "reference": correct, "mutants": mutations, "valid": ok})
        print(f"{task['id']}: reference={correct['status']} mutants={[m['grade']['status'] for m in mutations]}", flush=True)
    report = {"dataset_sha256": digest(ts), "valid": all(r["valid"] for r in rows), "tasks": rows}
    write_json(ROOT / "validation.json", report)
    return report["valid"]


class BudgetExceeded(RuntimeError):
    pass


class AccountingError(RuntimeError):
    pass


class Budget:
    """Reserve pessimistic input bytes + full completion capacity before requests.

    The guard uses peak prices even when actual requests occur off-peak. Unknown
    billing on errors retains the full reservation, and no automatic retry occurs.
    """
    def __init__(self, limit, spent=0.0):
        self.limit = limit
        self.spent = spent
        self.reserved = 0.0
        self.lock = asyncio.Lock()

    async def reserve(self, amount):
        async with self.lock:
            if self.spent + self.reserved + amount > self.limit:
                raise BudgetExceeded("Conservative CNY spending guard reached")
            self.reserved += amount

    async def settle(self, reserved, actual):
        async with self.lock:
            self.reserved -= reserved
            self.spent += actual


def usage_cost(usage, peak=True):
    p, c = usage.get("prompt_tokens"), usage.get("completion_tokens")
    if not isinstance(p, int) or not isinstance(c, int) or min(p, c) < 0:
        raise AccountingError("Missing valid token usage; stop rather than guess billing")
    hit = int(usage.get("prompt_cache_hit_tokens", 0))
    hit = min(max(hit, 0), p)
    multiplier = 1 if peak else 0.5
    return multiplier * ((p - hit) * 2 + hit * .04 + c * 8) / 1_000_000


def is_peak(now):
    # This pilot is 2026-10-30 after 18:00 CST (off-peak). For other dates,
    # weekday windows conservatively treat public holidays as ordinary weekdays.
    local = now.astimezone(dt.timezone(dt.timedelta(hours=8)))
    return local.weekday() < 5 and (9 <= local.hour < 12 or 14 <= local.hour < 18)


class API:
    def __init__(self, key, config, output, spent=0):
        self.key = key
        self.config = config
        self.output = output
        self.budget = Budget(config["spending_guard_cny"], spent)
        self.sem = asyncio.Semaphore(config["api_concurrency"])
        self.counter = max((int(p.stem) for p in (output / "calls").glob("*.json")), default=0)

    def request(self, endpoint, payload=None):
        url = "https://api.deepseek.com" + endpoint
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
        request = urllib.request.Request(url, data=data, headers={"Authorization": "Bearer " + self.key, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(request, timeout=150) as response:
                return json.load(response)
        except urllib.error.HTTPError as e:
            # Do not record response bodies or request objects; they can contain
            # sensitive provider metadata. Status code is sufficient for diagnosis.
            raise RuntimeError(f"DeepSeek HTTP {e.code}") from None
        except Exception as e:
            raise RuntimeError(f"DeepSeek request failed: {type(e).__name__}") from None

    async def complete(self, system, user, metadata):
        payload = {"model": self.config["model"], "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}], "temperature": self.config["temperature"], "thinking": {"type": "disabled"}, "max_tokens": self.config["max_tokens_per_call"], "stream": False}
        # UTF-8 bytes are a conservative bound on text tokens, with margin for
        # chat framing. Twice the bound further protects unusual tokenizers.
        prompt_bound = 2 * len(json.dumps(payload["messages"], ensure_ascii=False).encode()) + 2048
        reservation = (prompt_bound * 2 + payload["max_tokens"] * 8) / 1_000_000
        if prompt_bound > 150_000:
            raise ValueError("Request exceeds the pilot input size guard")
        async with self.sem:
            await self.budget.reserve(reservation)
            self.counter += 1
            number = self.counter
            started = time.perf_counter()
            now = dt.datetime.now(dt.timezone.utc)
            row = {"number": number, **metadata, "started_at": now.isoformat(), "request": payload, "reserved_cny": reservation}
            # Persist before sending: a crash after billing must not erase the
            # spending reservation when a run resumes.
            row["status"] = "pending"
            write_json(self.output / "calls" / f"{number:05d}.json", row)
            settled = False
            try:
                response = await asyncio.to_thread(self.request, "/chat/completions", payload)
                row.update({"response": response, "elapsed_seconds": time.perf_counter() - started})
                cost = usage_cost(response.get("usage", {}))
                if cost > reservation:
                    raise AccountingError("Provider usage exceeded pessimistic reservation")
                await self.budget.settle(reservation, cost)
                settled = True
                row["cost_peak_cny"] = cost
                row["cost_estimate_cny"] = usage_cost(response["usage"], peak=is_peak(now))
                choice = response["choices"][0]
                row["status"] = "ok"
                write_json(self.output / "calls" / f"{number:05d}.json", row)
                return choice["message"].get("content") or "", row
            except BaseException as e:
                # Keep pessimistic billing for unknown/error responses. The run
                # stops on infrastructure faults, so retries cannot drain budget.
                if not settled:
                    await self.budget.settle(reservation, reservation)
                    row["cost_peak_cny"] = reservation
                row.update({"status": "error", "error_type": type(e).__name__, "elapsed_seconds": time.perf_counter() - started})
                write_json(self.output / "calls" / f"{number:05d}.json", row)
                raise


class MeasuredModel(LanguageModel):
    def __init__(self, api, task_id, repeat, group, initial=None):
        self.api, self.task_id, self.repeat, self.group = api, task_id, repeat, group
        self.initial = initial
        self.records = []
        self.pending = set()
        self.request_errors = []
        self.calls_started = 0

    async def complete(self, system, user):
        if self.initial is not None and "[DIRECT_EXECUTE]" in system:
            return self.initial
        if self.calls_started >= 11:
            raise ValueError("Unexpected model call count")
        self.calls_started += 1
        current = asyncio.current_task()
        self.pending.add(current)
        try:
            text, record = await self.api.complete(system, user, {"task_id": self.task_id, "repeat": self.repeat, "group": self.group, "stage": system.splitlines()[0]})
            self.records.append(record)
            return text
        except BaseException as error:
            self.request_errors.append(error)
            raise
        finally:
            self.pending.discard(current)

    async def drain(self):
        # Upstream gather does not cancel siblings after malformed model JSON.
        # Wait for outstanding requests before freezing condition metrics.
        others = [p for p in self.pending if p is not asyncio.current_task()]
        if others:
            await asyncio.gather(*others, return_exceptions=True)
        if self.request_errors:
            raise self.request_errors[0]


async def self_refine(model, task, initial):
    current = initial
    for _ in range(5):
        feedback = await model.complete(FEEDBACK, json.dumps({"task": task, "candidate": current}, ensure_ascii=False))
        current = await model.complete(REWRITE, json.dumps({"task": task, "candidate": current, "feedback": feedback}, ensure_ascii=False))
    return current


def metrics(records):
    return {
        "physical_calls": len(records),
        "prompt_tokens": sum(r.get("response", {}).get("usage", {}).get("prompt_tokens", 0) for r in records),
        "completion_tokens": sum(r.get("response", {}).get("usage", {}).get("completion_tokens", 0) for r in records),
        "cost_peak_cny": sum(r.get("cost_peak_cny", 0) for r in records),
        "cost_estimate_cny": sum(r.get("cost_estimate_cny", r.get("cost_peak_cny", 0)) for r in records),
        "truncated_calls": sum(r.get("response", {}).get("choices", [{}])[0].get("finish_reason") == "length" for r in records),
    }


async def run_task(api, task, repeat, out):
    tid = task["id"]
    destination = out / "results" / f"{tid}_r{repeat}.json"
    if destination.exists():
        return
    prompt = task["prompt"] + CODE_RULE
    direct = MeasuredModel(api, tid, repeat, "direct")
    initial, initial_record = None, None
    checkpoint = out / "drafts" / f"{tid}_r{repeat}.json"
    if checkpoint.exists():
        saved = json.loads(checkpoint.read_text())
        initial, initial_record = saved["text"], saved["record"]
    else:
        initial = await direct.complete(DIRECT_EXECUTE, f"用户任务：\n{prompt}")
        initial_record = direct.records[0]
        write_json(checkpoint, {"text": initial, "record": initial_record})
    result = {"task_id": tid, "repeat": repeat, "category": task["category"], "groups": {}}
    result["groups"]["direct"] = {"output": initial, "metrics": metrics([initial_record]), "additional_seconds": 0, "total_wall_seconds": initial_record["elapsed_seconds"]}

    async def condition(group):
        model = MeasuredModel(api, tid, repeat, group, initial=initial if group == "dualpath" else None)
        started = time.perf_counter()
        try:
            if group == "dualpath":
                raw = await DualPath(model=model, search=NoSearch(), max_problems=5).run(prompt)
                text, extra = raw.final_output, {"dualpath_record": raw.to_dict()}
            else:
                text, extra = await self_refine(model, prompt, initial), {}
            await model.drain()
            return {"output": text, **extra, "metrics": metrics([initial_record] + model.records), "additional_seconds": time.perf_counter() - started, "total_wall_seconds": initial_record["elapsed_seconds"] + time.perf_counter() - started}
        except (ValueError, KeyError, TypeError) as e:
            # Invalid model-produced JSON is a method failure, not an opportunity
            # for unbudgeted repair. Preserve it in the intention-to-treat score.
            await model.drain()
            return {"output": "", "method_error": type(e).__name__ + ": " + str(e)[:180], "metrics": metrics([initial_record] + model.records), "additional_seconds": time.perf_counter() - started}
        finally:
            await model.drain()

    groups = ["self_refine", "dualpath"]
    # Both conditions run concurrently; no hidden feedback is supplied to either.
    computed = await asyncio.gather(*(condition(g) for g in groups), return_exceptions=True)
    fatal = None
    for group, value in zip(groups, computed):
        if isinstance(value, BaseException):
            fatal = value
            result["groups"][group] = {"infrastructure_error": type(value).__name__}
        else:
            result["groups"][group] = value
    if fatal:
        write_json(out / "incomplete" / destination.name, result)
        raise fatal
    for group, row in result["groups"].items():
        code = extract_code(row["output"])
        row["grade"] = await asyncio.to_thread(grade, code, task["tests"], timeout=8)
        if row["grade"]["status"] == "infrastructure_error":
            write_json(out / "incomplete" / destination.name, result)
            raise RuntimeError("Grader infrastructure failure")
    write_json(destination, result)
    statuses = " ".join(f"{g}={r['grade']['status']}" for g, r in result["groups"].items())
    print(f"{tid} r{repeat}: {statuses}; conservative spend={api.budget.spent:.4f} CNY", flush=True)


async def run(args):
    ts = tasks()
    valid = json.loads((ROOT / "validation.json").read_text())
    if not valid["valid"] or valid["dataset_sha256"] != digest(ts):
        raise ValueError("Validate the exact frozen dataset before model calls")
    out = ROOT / args.output
    out.mkdir(parents=True, exist_ok=True)
    run_lock = (out / ".run.lock").open("a")
    fcntl.flock(run_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    config = {"model": "deepseek-flash", "thinking": "disabled", "temperature": .2, "max_tokens_per_call": 2048, "api_concurrency": 6, "task_concurrency": 2, "task_count": 30, "repeats": args.repeats, "search": "disabled_all_groups", "shared_initial_draft": True, "self_refine_rounds": 5, "max_problems": 5, "spending_guard_cny": min(args.budget, 9.5), "authorized_budget_cny": 10, "dataset_sha256": digest(ts), "upstream_commit": REF, "seed": 20261030, "price_source": "https://api-docs.deepseek.com/zh-cn/quick_start/pricing/", "price_verified_date": "2026-10-30", "peak_cny_per_million": {"input_miss": 2, "input_hit": .04, "output": 8}, "offpeak_cny_per_million": {"input_miss": 1, "input_hit": .02, "output": 4}, "budget_matching": "Same max logical calls (11) and per-call output cap (2048) for self_refine and DualPath; actual total tokens differ and are reported. Direct is low-cost reference.", "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT / "vendor").rglob("*.py"))}}
    config["prompts_sha256"] = digest({"code_rule": CODE_RULE, "feedback": FEEDBACK, "rewrite": REWRITE})
    config["harness_sha256"] = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ("experiment.py", "evaluate.py")}
    manifest = out / "protocol.json"
    if manifest.exists() and json.loads(manifest.read_text()) != config:
        raise ValueError("Resume protocol does not match; choose another output directory")
    write_json(manifest, config)
    oldcalls = [json.loads(p.read_text()) for p in (out / "calls").glob("*.json")]
    if any(r.get("status") != "ok" for r in oldcalls):
        raise RuntimeError("Unresolved or failed API calls exist; inspect accounting before resuming")
    if list((out / "incomplete").glob("*.json")):
        raise RuntimeError("Incomplete task pairs exist; do not silently rerun selected conditions")
    if any(r.get("group") != "direct" and not (out / "results" / f"{r['task_id']}_r{r['repeat']}.json").exists() for r in oldcalls):
        raise RuntimeError("Condition calls without a completed pair exist; inspect instead of resampling")
    spent = sum(r.get("cost_peak_cny", r.get("reserved_cny", 0)) for r in oldcalls)
    key = os.environ.get("DEEPSEEK_API_KEY") or getpass.getpass("DeepSeek API key (hidden, memory only): ")
    if not key:
        raise ValueError("No API key configured")
    api = API(key.strip(), config, out, spent)
    balance = await asyncio.to_thread(api.request, "/user/balance")
    if not balance.get("is_available"):
        raise RuntimeError("DeepSeek account has no available balance")
    # Account totals stay in memory; only task-spend estimates are saved.
    print("API authenticated; dataset frozen; spending guard active.", flush=True)
    jobs = [(task, repeat) for repeat in range(1, args.repeats + 1) for task in ts]
    random.Random(config["seed"]).shuffle(jobs)
    if args.limit:
        jobs = jobs[:args.limit]
    stopped = None
    for start in range(0, len(jobs), config["task_concurrency"]):
        batch = jobs[start:start + config["task_concurrency"]]
        values = await asyncio.gather(*(run_task(api, task, repeat, out) for task, repeat in batch), return_exceptions=True)
        failures = [v for v in values if isinstance(v, BaseException)]
        if failures:
            stopped = type(failures[0]).__name__ + ": " + str(failures[0])[:200]
            print("Run stopped: " + stopped, flush=True)
            break
    write_json(out / "run_status.json", {"stopped_reason": stopped, "conservative_spend_cny": api.budget.spent, "outstanding_reserved_cny": api.budget.reserved, "completed_records": len(list((out / "results").glob("*.json"))), "planned_records": 30 * args.repeats})
    summarize(out)


def wilson(k, n):
    if not n:
        return [0, 1]
    z = 1.959963984540054
    denominator = 1 + z*z/n
    mid = (k/n + z*z/(2*n)) / denominator
    half = z * math.sqrt(k/n * (1-k/n)/n + z*z/(4*n*n)) / denominator
    return [mid-half, mid+half]


def exact_paired_p(wins, losses):
    n = wins + losses
    if n == 0:
        return 1.0
    return min(1.0, 2 * sum(math.comb(n, i) for i in range(min(wins, losses) + 1)) / 2**n)


def summarize(out):
    rows = [json.loads(p.read_text()) for p in sorted((out / "results").glob("*.json"))]
    calls = [json.loads(p.read_text()) for p in sorted((out / "calls").glob("*.json"))]
    result = {"completed_pairs": len(rows), "groups": {}, "paired_comparisons": {}, "physical_api": metrics(calls)}
    for group in ("direct", "self_refine", "dualpath"):
        values = [r["groups"][group] for r in rows]
        k = sum(v["grade"]["passed"] for v in values)
        total = len(values)
        result["groups"][group] = {"passed": k, "total": total, "pass_rate": k/total if total else None, "wilson_95_interval": wilson(k, total), "method_errors": sum("method_error" in v for v in values), "mean_prompt_tokens": statistics.mean(v["metrics"]["prompt_tokens"] for v in values) if values else 0, "mean_completion_tokens": statistics.mean(v["metrics"]["completion_tokens"] for v in values) if values else 0, "mean_cost_estimate_cny": statistics.mean(v["metrics"]["cost_estimate_cny"] for v in values) if values else 0, "mean_additional_seconds": statistics.mean(v["additional_seconds"] for v in values) if values else 0, "truncated_calls": sum(v["metrics"]["truncated_calls"] for v in values)}
    for improved, base in (("self_refine", "direct"), ("dualpath", "direct"), ("dualpath", "self_refine")):
        wins = sum(r["groups"][improved]["grade"]["passed"] and not r["groups"][base]["grade"]["passed"] for r in rows)
        losses = sum(not r["groups"][improved]["grade"]["passed"] and r["groups"][base]["grade"]["passed"] for r in rows)
        result["paired_comparisons"][improved + "_vs_" + base] = {"wins": wins, "losses": losses, "ties": len(rows)-wins-losses, "exact_mcnemar_p": exact_paired_p(wins, losses)}
    result["limitations"] = ["Exploratory custom benchmark; no claim of general superiority.", "Only one repeat by default; Wilson/McNemar summaries assume one independent task per row. Repeated runs are correlated and require task-clustered inference.", "Actual token use differs despite equal maximum calls/output caps; interpret cost-quality jointly.", "All methods have no search, no tools, no hidden-test feedback, and thinking disabled.", "Shared initial draft makes paired quality comparisons stronger, but recorded wall time is not unmodified production DualPath latency.", "Incompletely executed pairs are excluded and separately retained; errors in model JSON are scored as method failures."]
    write_json(out / "summary.json", result)
    print(json.dumps({"complete": len(rows), "scores": {g: f"{v['passed']}/{v['total']}" for g,v in result['groups'].items()}, "api_cost_estimate_cny": result['physical_api']['cost_estimate_cny']}, ensure_ascii=False), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["validate", "run", "report"])
    parser.add_argument("--output", default="runs/pilot")
    parser.add_argument("--budget", type=float, default=9.5)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--repeats", type=int, default=1)
    args = parser.parse_args()
    if args.command == "validate":
        sys.exit(0 if validate() else 1)
    if args.command == "report":
        summarize(ROOT / args.output)
    if args.command == "run":
        asyncio.run(run(args))


if __name__ == "__main__":
    main()
