"""Offline audit of the frozen pilot. No API access or credentials needed.

Replays exact recorded requests through the frozen orchestrators, independently
recomputes usage/costs, and executes all outputs and controls in bubblewrap.
Original evidence is read-only; only audit/verification.json is written.
"""
from __future__ import annotations

import asyncio
from collections import Counter, defaultdict, deque
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path

import experiment as exp
from evaluate import extract_code, grade

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "runs/pilot"
GROUPS = ("direct", "self_refine", "dualpath")


def read(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def content(call):
    return call["response"]["choices"][0]["message"].get("content") or ""


def request_key(system, user):
    return (system, user)


class Replay:
    def __init__(self, calls, initial=None, prompt=None):
        self.queues = defaultdict(deque)
        self.initial = initial
        self.prompt = prompt
        self.consumed = []
        self.shared_draft_calls = 0
        for call in calls:
            messages = call["request"]["messages"]
            self.queues[request_key(messages[0]["content"], messages[1]["content"])].append(call)

    async def complete(self, system, user):
        if self.initial is not None and system == exp.DIRECT_EXECUTE:
            check(user == "用户任务：\n" + self.prompt, "shared draft task mismatch")
            self.shared_draft_calls += 1
            return self.initial
        queue = self.queues.get(request_key(system, user))
        check(bool(queue), f"unrecorded replay request: {system.splitlines()[0]}")
        call = queue.popleft()
        self.consumed.append(call["number"])
        if call["status"] != "ok":
            raise RuntimeError("recorded infrastructure failure")
        return content(call)

    def finish(self):
        check(not any(self.queues.values()), "unconsumed recorded requests")


def cost(call):
    if call["status"] != "ok":
        return Decimal(str(call["reserved_cny"]))
    usage = call["response"]["usage"]
    prompt, completion = usage["prompt_tokens"], usage["completion_tokens"]
    hit, miss = usage["prompt_cache_hit_tokens"], usage["prompt_cache_miss_tokens"]
    check(hit + miss == prompt, "cache accounting mismatch")
    check(usage["total_tokens"] == prompt + completion, "token total mismatch")
    # Every recorded call occurred after 18:00 CST on 2026-10-30.
    check("2026-10-30T10:" <= call["started_at"] < "2026-10-30T12:", "offpeak assumption changed")
    return (Decimal(miss) + Decimal(hit) * Decimal("0.02") + Decimal(completion) * 4) / 1_000_000


def metrics(calls):
    return {
        "physical_calls": len(calls),
        "prompt_tokens": sum(c.get("response", {}).get("usage", {}).get("prompt_tokens", 0) for c in calls),
        "completion_tokens": sum(c.get("response", {}).get("usage", {}).get("completion_tokens", 0) for c in calls),
        "cost_estimate_cny": float(sum((cost(c) for c in calls), Decimal(0))),
        "cost_peak_cny": float(sum((cost(c) * (2 if c["status"] == "ok" else 1) for c in calls), Decimal(0))),
        "truncated_calls": sum(c.get("response", {}).get("choices", [{}])[0].get("finish_reason") == "length" for c in calls),
    }


def comparison(rows, a, b):
    wins = sum(r[a] and not r[b] for r in rows)
    losses = sum(r[b] and not r[a] for r in rows)
    n = wins + losses
    p = min(1, 2 * sum(math.comb(n, i) for i in range(min(wins, losses) + 1)) / 2**n) if n else 1
    return {"wins": wins, "losses": losses, "ties": len(rows)-n, "exact_mcnemar_p": p}


async def main():
    protocol = read(RUN / "protocol.json")
    tasks = exp.tasks()
    check(exp.digest(tasks) == protocol["dataset_sha256"], "dataset changed")
    check(exp.digest({"code_rule": exp.CODE_RULE, "feedback": exp.FEEDBACK, "rewrite": exp.REWRITE}) == protocol["prompts_sha256"], "prompts changed")
    hashes = {**protocol["source_sha256"], **protocol["harness_sha256"]}
    for name, expected in hashes.items():
        check(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, f"frozen source changed: {name}")
    calls = [read(p) for p in sorted((RUN / "calls").glob("*.json"))]
    check([c["number"] for c in calls] == list(range(1, 628)), "call sequence changed")
    check(Counter(c["status"] for c in calls) == {"ok": 626, "error": 1}, "status counts changed")
    for c in calls:
        q = c["request"]
        check(q["model"] == "deepseek-flash" and q["temperature"] == .2 and q["max_tokens"] == 2048 and q["thinking"] == {"type": "disabled"} and q["stream"] is False, "request parameters changed")
        check([m["role"] for m in q["messages"]] == ["system", "user"], "unexpected messages")
        if c["status"] == "ok":
            check(c["response"]["model"] == q["model"], "response model mismatch")
        expected = c.get("cost_estimate_cny", c["cost_peak_cny"])
        check(math.isclose(float(cost(c)), expected, abs_tol=1e-12), "stored call cost mismatch")
    results = [read(p) for p in sorted((RUN / "results").glob("*.json"))]
    check([r["task_id"] for r in results] == [t["id"] for t in tasks], "task coverage changed")
    by_task = defaultdict(list)
    for c in calls:
        check(c["repeat"] == 1 and c["group"] in GROUPS, "unexpected repeat/group")
        by_task[c["task_id"]].append(c)
    rows, controls, replay_rows = [], [], []
    for task, result in zip(tasks, results):
        tid = task["id"]
        prompt = task["prompt"] + exp.CODE_RULE
        records = by_task[tid]
        direct_calls = [c for c in records if c["group"] == "direct"]
        check(len(direct_calls) == 1, "direct sampling count")
        direct = direct_calls[0]
        initial = content(direct)
        check(direct["request"]["messages"] == [{"role": "system", "content": exp.DIRECT_EXECUTE}, {"role": "user", "content": "用户任务：\n" + prompt}], "initial prompt mismatch")
        draft = read(RUN / "drafts" / f"{tid}_r1.json")
        check(draft == {"text": initial, "record": direct}, "checkpoint mismatch")
        check(result["groups"]["direct"]["output"] == initial, "direct output mismatch")
        for group in GROUPS:
            group_calls = [c for c in records if c["group"] == group]
            selected = group_calls if group == "direct" else direct_calls + group_calls
            calculated = metrics(selected)
            for key, value in calculated.items():
                check(math.isclose(value, result["groups"][group]["metrics"][key], abs_tol=1e-10), f"group metrics mismatch: {tid}/{group}/{key}")
        self_calls = [c for c in records if c["group"] == "self_refine"]
        replay = Replay(self_calls)
        self_output = await exp.self_refine(replay, prompt, initial)
        replay.finish()
        check(self_output == result["groups"]["self_refine"]["output"], "self replay output mismatch")
        dual_calls = [c for c in records if c["group"] == "dualpath"]
        abandoned = []
        if tid == "DP003":
            start = max(c["number"] for c in dual_calls if c["stage"] == "[ERROR_DISCOVER]")
            abandoned = [c for c in dual_calls if c["number"] < start]
            dual_calls = [c for c in dual_calls if c["number"] >= start]
            check(len(abandoned) == 6 and sum(c["status"] == "error" for c in abandoned) == 1, "retry history changed")
            check(result["groups"]["dualpath"]["recovered_from_infrastructure"] is True, "missing retry disclosure")
            failed_replay = Replay(abandoned, initial, prompt)
            try:
                await exp.DualPath(model=failed_replay, search=exp.NoSearch(), max_problems=5).run(prompt)
            except RuntimeError as error:
                check(str(error) == "recorded infrastructure failure", "unexpected replay exception")
            else:
                raise AssertionError("failed attempt unexpectedly succeeded")
            failed_replay.finish()
        replay = Replay(dual_calls, initial, prompt)
        expected_dual = result["groups"]["dualpath"]
        try:
            raw = await exp.DualPath(model=replay, search=exp.NoSearch(), max_problems=5).run(prompt)
        except ValueError as error:
            check(expected_dual.get("method_error") == "ValueError: " + str(error)[:180], "method error mismatch")
            check(expected_dual["output"] == "", "method error has output")
        else:
            check(raw.final_output == expected_dual["output"], "dual replay output mismatch")
            actual, expected = raw.to_dict(), dict(expected_dual["dualpath_record"])
            for key in ("started_at", "finished_at"):
                actual.pop(key)
                expected.pop(key)
            check(actual == expected, "dual intermediate state mismatch")
        replay.finish()
        check(replay.shared_draft_calls == 1, "shared draft replay mismatch")
        replay_rows.append({"task_id": tid, "exact_request_and_output_replay": True, "discarded_attempt_calls": [c["number"] for c in abandoned]})
        grades = {}
        for group in GROUPS:
            grades[group] = grade(extract_code(result["groups"][group]["output"]), task["tests"], timeout=8)
            check(grades[group]["status"] == result["groups"][group]["grade"]["status"], f"regrade differs: {tid}/{group}")
        rows.append({"task_id": tid, "grades": grades})
        reference = grade(task["reference"], task["tests"], timeout=8)
        mutants = [{"name": m["name"], "grade": grade(m["code"], task["tests"], timeout=8)} for m in task["mutants"]]
        check(reference["status"] == "pass" and all(m["grade"]["status"] == "fail" for m in mutants), "reference/mutation validation failed")
        controls.append({"task_id": tid, "reference": reference, "mutants": mutants})
        print(f"{tid}: exact replay + regrade + controls verified", flush=True)
    scores = [{"task_id": r["task_id"], **{g: r["grades"][g]["passed"] for g in GROUPS}} for r in rows]
    sensitivity = {}
    for label, excluded in [("primary", []), ("exclude_retried_task", ["DP003"]), ("exclude_ambiguous_task", ["DP005"]), ("exclude_both", ["DP003", "DP005"])]:
        selected = [r for r in scores if r["task_id"] not in excluded]
        sensitivity[label] = {"n": len(selected), "excluded": excluded, "passed": {g: sum(r[g] for r in selected) for g in GROUPS}}
    estimated = sum((cost(c) for c in calls), Decimal(0))
    unknown = sum((cost(c) for c in calls if c["status"] != "ok"), Decimal(0))
    report = {
        "audit_date": "2026-10-31", "offline_only": True, "new_paid_calls": 0,
        "frozen_hashes_verified": hashes, "dataset_sha256": protocol["dataset_sha256"],
        "checks_passed": True, "model_outputs_regraded": 90, "reference_solutions_passed": 30, "mutants_rejected": 30,
        "physical_api": metrics(calls), "cost_usage_estimate_cny": str(estimated - unknown), "unknown_failure_reserve_cny": str(unknown),
        "cost_including_reserve_cny": str(estimated), "provider_bill_verified": False,
        "paired_comparisons": {a + "_vs_" + b: comparison(scores, a, b) for a, b in [("self_refine", "direct"), ("dualpath", "direct"), ("dualpath", "self_refine")]},
        "sensitivity": sensitivity, "replay": replay_rows, "grades": rows, "controls": controls,
    }
    exp.write_json(ROOT / "audit/verification.json", report)
    print(json.dumps({k: v for k, v in report.items() if k not in {"replay", "grades", "controls", "frozen_hashes_verified"}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
