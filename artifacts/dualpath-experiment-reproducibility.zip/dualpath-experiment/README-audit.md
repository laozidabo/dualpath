DualPath 冻结实验的离线复验包

包内 `REPORT.zh-CN.md` 是中文结论。`runs/pilot/` 保存冻结协议、627 次请求记录、30 份初稿及 30 组结果。原代码对应上游提交 ff23e7e07db44b2c11fb9d60ec946439958757f6；`vendor/LICENSE` 保留上游许可。

原始材料：`experiment.py`、`evaluate.py`、`bench/`、`vendor/`、`validation.json`、`runs/pilot/`。接续者增加的恢复程序为 `resume.py`。本轮新增的离线审计为 `audit.py`、`posthoc.py` 及 `audit/`，未修改冻结文件。

在解压目录执行以下命令。需要 Linux、Python 3.10+ 标准库、`/usr/bin/python3` 和支持用户命名空间隔离的 bubblewrap (`bwrap`)。本次环境 Python 3.14；不需要 pip 包、网络或 API 密钥。隔离不可用时应先修复环境，不要取消沙箱运行模型代码。

```bash
sha256sum -c SHA256SUMS
python -m unittest discover -s tests -v
python audit.py
python posthoc.py
```

`audit.py` 核对冻结哈希、精确回放所有模型请求，重新执行 90 份答案、30 份参考实现和 30 个错误实现，并将审计结果写入 `audit/verification.json`。它不调用远程接口。`posthoc.py` 复验 30 份第一轮自审答案及 4 个最小案例，更新两个对应的 audit JSON。耗时与本机隔离进程启动速度有关。

审计输出含执行耗时，重跑会改变其哈希；请在重跑前验证 SHA256SUMS。每次审计仍会核对原始材料在 protocol.json 中的哈希，不依赖已生成的 audit JSON。

`experiment.py run` 和 `resume.py` 是历史在线运行入口，会访问收费模型，不是上述复验的必要步骤。本包不含密钥，也不建议将已完成实验再次在线运行：新的调用应另立协议、预算和输出位置，并避免混入现有记录。

已知解释限制：自建小题集、每组仅一次采样；DP003 发生一次基础设施失败并整组恢复，开销全部保留；DP005 的规则优先级存在歧义；DP026 的 DualPath 发现阶段输出截断，计方法失败。主结果和敏感性分析均见报告。第一轮自审属于事后分析。预算记录为按价格和 usage 的估算，未经账户账单确认。

原始调用日志包含自建题目、生成代码和模型解释文本，保留用于研究复验。封装前进行了 API-key 格式扫描，未发现匹配项。日志没有保存 Authorization 请求头。
