import copy
import json
import pathlib
import textwrap


TASKS = []


def add(number, category, entry_point, prompt, reference, tests, mutant_name, old, new):
    reference = textwrap.dedent(reference).strip() + "\n"
    tests = textwrap.dedent(tests).strip() + "\n"
    assert old in reference, (number, old)
    mutant = reference.replace(old, new, 1)
    assert mutant != reference
    TASKS.append({
        "id": f"DP{number:03d}",
        "category": category,
        "entry_point": entry_point,
        "prompt": textwrap.dedent(prompt).strip(),
        "reference": reference,
        "tests": tests,
        "mutants": [{"name": mutant_name, "code": mutant}],
    })


add(1, "interval_union", "merge_intervals", r'''
实现 Python 函数 `merge_intervals(intervals)`。输入是若干 `(start, end)` 整数二元组构成的列表，表示半开区间 `[start, end)`。返回这些区间的并集，形式为按起点升序排列的二元组列表。重叠或首尾相接的区间均应合并；零长度区间忽略；任意区间 start > end 时抛出 ValueError。输入允许未排序、重复、负数以及非常大的整数，不得修改输入，空输入返回 []。只能使用标准库。
公开例子：
`merge_intervals([(5, 8), (1, 3), (3, 6)]) == [(1, 8)]`
`merge_intervals([(-3, -1), (2, 2), (4, 7)]) == [(-3, -1), (4, 7)]`
请给出完整函数实现及必要的导入。
''', '''
def merge_intervals(intervals):
    valid = []
    for start, end in intervals:
        if start > end:
            raise ValueError("reversed interval")
        if start < end:
            valid.append((start, end))
    result = []
    for start, end in sorted(valid):
        if result and start <= result[-1][1]:
            result[-1] = (result[-1][0], max(result[-1][1], end))
        else:
            result.append((start, end))
    return result
''', '''
import random
assert merge_intervals([]) == []
assert merge_intervals([(1, 1)]) == []
assert merge_intervals([(1, 2)]) == [(1, 2)]
assert merge_intervals([(5, 8), (1, 3), (3, 6)]) == [(1, 8)]
assert merge_intervals([(-3, -1), (2, 2), (4, 7)]) == [(-3, -1), (4, 7)]
assert merge_intervals([(0, 10), (2, 3), (5, 8)]) == [(0, 10)]
assert merge_intervals([(1, 2), (1, 2)]) == [(1, 2)]
assert merge_intervals([(4, 5), (1, 2), (2, 4)]) == [(1, 5)]
assert merge_intervals([(0, 2), (3, 4)]) == [(0, 2), (3, 4)]
assert merge_intervals([(-10**30, 0), (0, 10**30)]) == [(-10**30, 10**30)]
for bad in [[(2, 1)], [(0, 10), (7, 6)], [(3, 3), (-1, -2)]]:
    try:
        merge_intervals(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("reversed interval accepted")
rng = random.Random(101)
for _ in range(120):
    source = [tuple(sorted((rng.randrange(-12, 13), rng.randrange(-12, 13)))) for _ in range(rng.randrange(20))]
    snapshot = list(source)
    covered = {x for a, b in source for x in range(a, b)}
    expected = []
    for x in sorted(covered):
        if expected and expected[-1][1] == x:
            expected[-1] = (expected[-1][0], x + 1)
        else:
            expected.append((x, x + 1))
    assert merge_intervals(source) == expected
    assert source == snapshot
''', "touching_intervals_left_separate", "start <= result[-1][1]", "start < result[-1][1]")


add(2, "interval_difference", "subtract_intervals", r'''
实现 Python 函数 `subtract_intervals(intervals, blocked)`。两个参数都是整数二元组列表，每个二元组表示半开区间 `[start, end)`。返回 intervals 的并集扣除 blocked 的并集后的区间列表，按起点升序，所有重叠或首尾相接的结果必须合并，不能包含零长度区间。输入可能乱序、重复或相互重叠；任意参数中 start > end 都须抛出 ValueError，零长度输入区间忽略。不得修改输入，必须支持非常大的端点，不能逐整数枚举区间内容。只能使用标准库。
公开例子：
`subtract_intervals([(0, 10)], [(2, 4), (6, 12)]) == [(0, 2), (4, 6)]`
`subtract_intervals([(5, 8), (1, 5)], [(3, 6)]) == [(1, 3), (6, 8)]`
请给出完整函数实现及必要的导入。
''', '''
def subtract_intervals(intervals, blocked):
    def merged(items):
        cleaned = []
        for a, b in items:
            if a > b:
                raise ValueError("reversed interval")
            if a < b:
                cleaned.append((a, b))
        out = []
        for a, b in sorted(cleaned):
            if out and a <= out[-1][1]:
                out[-1] = (out[-1][0], max(out[-1][1], b))
            else:
                out.append((a, b))
        return out
    available, cuts = merged(intervals), merged(blocked)
    result = []
    j = 0
    for start, end in available:
        cursor = start
        while j < len(cuts) and cuts[j][1] <= cursor:
            j += 1
        k = j
        while k < len(cuts) and cuts[k][0] < end:
            left, right = cuts[k]
            if cursor < left:
                result.append((cursor, min(left, end)))
            cursor = max(cursor, right)
            if cursor >= end:
                break
            k += 1
        if cursor < end:
            result.append((cursor, end))
        j = k
    return result
''', '''
import random
assert subtract_intervals([], []) == []
assert subtract_intervals([], [(1, 2)]) == []
assert subtract_intervals([(0, 10)], []) == [(0, 10)]
assert subtract_intervals([(0, 10)], [(2, 4), (6, 12)]) == [(0, 2), (4, 6)]
assert subtract_intervals([(5, 8), (1, 5)], [(3, 6)]) == [(1, 3), (6, 8)]
assert subtract_intervals([(0, 10)], [(-1, 20)]) == []
assert subtract_intervals([(0, 2)], [(2, 5)]) == [(0, 2)]
assert subtract_intervals([(0, 2)], [(-2, 0)]) == [(0, 2)]
assert subtract_intervals([(0, 2), (4, 6), (8, 10)], [(1, 9)]) == [(0, 1), (9, 10)]
assert subtract_intervals([(0, 10)], [(2, 4), (3, 8), (8, 9)]) == [(0, 2), (9, 10)]
assert subtract_intervals([(0, 0), (4, 4)], [(1, 1)]) == []
assert subtract_intervals([(-10**30, 10**30)], [(-1, 1)]) == [(-10**30, -1), (1, 10**30)]
for left, right in [([(2, 1)], []), ([], [(2, 1)]), ([(0, 0)], [(4, 3)])]:
    try:
        subtract_intervals(left, right)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid interval accepted")
rng = random.Random(102)
for _ in range(150):
    left = [tuple(sorted((rng.randrange(-10, 11), rng.randrange(-10, 11)))) for _ in range(rng.randrange(12))]
    right = [tuple(sorted((rng.randrange(-10, 11), rng.randrange(-10, 11)))) for _ in range(rng.randrange(12))]
    before = (list(left), list(right))
    remaining = {i for a, b in left for i in range(a, b)} - {i for a, b in right for i in range(a, b)}
    expected = []
    for i in sorted(remaining):
        if expected and expected[-1][1] == i:
            expected[-1] = (expected[-1][0], i + 1)
        else:
            expected.append((i, i + 1))
    assert subtract_intervals(left, right) == expected
    assert (left, right) == before
''', "consume_block_spanning_multiple_source_intervals", "j = k\n    return result", "j = k + 1\n    return result")


add(3, "escaped_delimiter_parser", "split_escaped", r'''
实现 Python 函数 `split_escaped(text, separator=',')`。text 是字符串，separator 必须是恰好一个字符且不是反斜杠，否则抛出 ValueError。把未被转义的 separator 当作字段分隔符。反斜杠转义紧随其后的任意一个字符：反斜杠本身被去掉，下一个字符原样进入字段；这也适用于分隔符、反斜杠、空格、换行和 Unicode 字符。保留所有空字段，空字符串返回 ['']。末尾孤立的反斜杠必须抛出 ValueError。不要进行额外的空白裁剪或引号处理。只能使用标准库。
公开例子（使用 Python 字符串表示法）：
`split_escaped(r'a\,b,,c\\') == ['a,b', '', 'c\\']`
`split_escaped('甲|乙||', '|') == ['甲', '乙', '', '']`
请给出完整函数实现及必要的导入。
''', r'''
def split_escaped(text, separator=','):
    if len(separator) != 1 or separator == chr(92):
        raise ValueError("invalid separator")
    result, current = [], []
    escaped = False
    for char in text:
        if escaped:
            current.append(char)
            escaped = False
        elif char == chr(92):
            escaped = True
        elif char == separator:
            result.append(''.join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        raise ValueError("dangling escape")
    result.append(''.join(current))
    return result
''', r'''
import random
assert split_escaped('') == ['']
assert split_escaped(',') == ['', '']
assert split_escaped(',,') == ['', '', '']
assert split_escaped('a,b,') == ['a', 'b', '']
assert split_escaped(r'a\,b,,c\\') == ['a,b', '', 'c\\']
assert split_escaped('甲|乙||', '|') == ['甲', '乙', '', '']
assert split_escaped(r'\x,\ y') == ['x', ' y']
assert split_escaped(r'\\,z') == ['\\', 'z']
assert split_escaped(' a , b ') == [' a ', ' b ']
assert split_escaped('a\\\nb,c') == ['a\nb', 'c']
assert split_escaped('a💡b💡', '💡') == ['a', 'b', '']
assert split_escaped('"a,b"') == ['"a', 'b"']
for text in ['\\', 'a\\', ',\\', '\\\\\\']:
    try:
        split_escaped(text)
    except ValueError:
        pass
    else:
        raise AssertionError("dangling escape accepted")
for sep in ['', 'ab', '\\']:
    try:
        split_escaped('', sep)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid separator accepted")
rng = random.Random(103)
for _ in range(150):
    sep = rng.choice([',', '|', '💡', '\n'])
    fields = [''.join(rng.choice('ab,|💡\\ \n') for _ in range(rng.randrange(12))) for _ in range(rng.randrange(1, 10))]
    encoded = sep.join(''.join('\\' + c if c in (sep, '\\') else c for c in field) for field in fields)
    assert split_escaped(encoded, sep) == fields
''', "drop_trailing_empty_field", "result.append(''.join(current))\n    return result", "if current:\n        result.append(''.join(current))\n    return result")


add(4, "sweep_line_concurrency", "busy_spans", r'''
实现 Python 函数 `busy_spans(intervals, minimum)`。intervals 是整数二元组列表，表示半开活动区间 `[start, end)`；每一个条目都是独立活动，因此重复区间也要重复计数。minimum 是整数，必须大于 0，否则抛出 ValueError。返回同时活动数至少为 minimum 的所有时间区间，格式为按起点升序的二元组列表；相邻的合格区间必须合并，即使内部活动数发生变化。start > end 抛出 ValueError，start == end 忽略。允许负数、巨大整数、乱序与重复；不得修改输入，也不能逐时间单位枚举。只能使用标准库。
公开例子：
`busy_spans([(0, 5), (2, 7), (4, 6)], 2) == [(2, 6)]`
`busy_spans([(0, 2), (2, 4)], 1) == [(0, 4)]`
请给出完整函数实现及必要的导入。
''', '''
def busy_spans(intervals, minimum):
    if minimum <= 0:
        raise ValueError("minimum must be positive")
    changes = {}
    for start, end in intervals:
        if start > end:
            raise ValueError("reversed interval")
        if start == end:
            continue
        changes[start] = changes.get(start, 0) + 1
        changes[end] = changes.get(end, 0) - 1
    result, active, previous = [], 0, None
    for time in sorted(changes):
        if previous is not None and previous < time and active >= minimum:
            if result and result[-1][1] == previous:
                result[-1] = (result[-1][0], time)
            else:
                result.append((previous, time))
        active += changes[time]
        previous = time
    return result
''', '''
import random
assert busy_spans([], 1) == []
assert busy_spans([(0, 5), (2, 7), (4, 6)], 2) == [(2, 6)]
assert busy_spans([(0, 2), (2, 4)], 1) == [(0, 4)]
assert busy_spans([(0, 2), (2, 4)], 2) == []
assert busy_spans([(0, 5), (0, 5)], 2) == [(0, 5)]
assert busy_spans([(0, 5)] * 4, 4) == [(0, 5)]
assert busy_spans([(0, 5)] * 4, 5) == []
assert busy_spans([(1, 1), (2, 2)], 1) == []
assert busy_spans([(0, 10), (2, 4), (6, 8)], 2) == [(2, 4), (6, 8)]
assert busy_spans([(-5, 0), (-3, 2), (0, 4)], 2) == [(-3, 2)]
assert busy_spans([(-10**30, 10**30)], 1) == [(-10**30, 10**30)]
assert busy_spans([(0, 3), (1, 2), (2, 4)], 1) == [(0, 4)]
for source, minimum in [([], 0), ([], -1), ([(3, 2)], 1)]:
    try:
        busy_spans(source, minimum)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid input accepted")
rng = random.Random(104)
for _ in range(150):
    source = [tuple(sorted((rng.randrange(-8, 9), rng.randrange(-8, 9)))) for _ in range(rng.randrange(15))]
    threshold = rng.randrange(1, 8)
    before = list(source)
    expected = []
    for x in range(-8, 8):
        if sum(a <= x < b for a, b in source) >= threshold:
            if expected and expected[-1][1] == x:
                expected[-1] = (expected[-1][0], x + 1)
            else:
                expected.append((x, x + 1))
    assert busy_spans(source, threshold) == expected
    assert source == before
''', "incorrectly_deduplicate_activities", "for start, end in intervals:", "for start, end in set(intervals):")


add(5, "stable_topological_sort", "schedule_tasks", r'''
实现 Python 函数 `schedule_tasks(tasks, dependencies)`。tasks 是互不重复的字符串列表，其原始位置代表优先级，位置越小优先级越高。dependencies 是 `(before, after)` 字符串二元组列表，表示 before 必须在 after 前完成，重复依赖只计算一次。返回一个任务排列：每一步都必须从此刻所有依赖已完成的任务中，选择在原 tasks 中位置最靠前的任务。空任务返回 []。tasks 中出现重复名称、依赖引用未知任务、或者依赖图存在环（包括自环）时，抛出 ValueError。不得修改输入。只能使用标准库。
公开例子：
`schedule_tasks(['a', 'b', 'c'], [('b', 'a')]) == ['b', 'a', 'c']`
`schedule_tasks(['x', 'y', 'z'], [('x', 'z'), ('y', 'z')]) == ['x', 'y', 'z']`
请给出完整函数实现及必要的导入。
''', '''
import heapq

def schedule_tasks(tasks, dependencies):
    index = {task: i for i, task in enumerate(tasks)}
    if len(index) != len(tasks):
        raise ValueError("duplicate task")
    outgoing = [set() for _ in tasks]
    indegree = [0] * len(tasks)
    for before, after in dependencies:
        if before not in index or after not in index:
            raise ValueError("unknown task")
        u, v = index[before], index[after]
        if v not in outgoing[u]:
            outgoing[u].add(v)
            indegree[v] += 1
    ready = [i for i, count in enumerate(indegree) if count == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        u = heapq.heappop(ready)
        result.append(tasks[u])
        for v in sorted(outgoing[u]):
            indegree[v] -= 1
            if indegree[v] == 0:
                heapq.heappush(ready, v)
    if len(result) != len(tasks):
        raise ValueError("cyclic dependencies")
    return result
''', '''
import itertools
import random
assert schedule_tasks([], []) == []
assert schedule_tasks(['x'], []) == ['x']
assert schedule_tasks(['c', 'a', 'b'], []) == ['c', 'a', 'b']
assert schedule_tasks(['a', 'b', 'c'], [('b', 'a')]) == ['b', 'a', 'c']
assert schedule_tasks(['x', 'y', 'z'], [('x', 'z'), ('y', 'z')]) == ['x', 'y', 'z']
assert schedule_tasks(['a', 'b', 'c'], [('c', 'b'), ('b', 'a')]) == ['c', 'b', 'a']
assert schedule_tasks(['a', 'b'], [('a', 'b'), ('a', 'b')]) == ['a', 'b']
assert schedule_tasks(['', 'x'], [('x', '')]) == ['x', '']
for tasks, deps in [(['a', 'a'], []), ([], [('a', 'b')]), (['a'], [('a', 'a')]), (['a', 'b'], [('a', 'b'), ('b', 'a')]), (['a', 'b', 'c'], [('b', 'c'), ('c', 'b')]), (['a'], [('a', 'missing')])]:
    try:
        schedule_tasks(tasks, deps)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid graph accepted")
rng = random.Random(105)
for _ in range(50):
    tasks = ['t' + str(i) for i in range(rng.randrange(2, 7))]
    shuffled = list(tasks)
    rng.shuffle(shuffled)
    deps = [(shuffled[i], shuffled[j]) for i in range(len(tasks)) for j in range(i + 1, len(tasks)) if rng.random() < 0.3]
    candidates = []
    for perm in itertools.permutations(tasks):
        positions = {name: i for i, name in enumerate(perm)}
        if all(positions[a] < positions[b] for a, b in deps):
            candidates.append(perm)
    expected = list(min(candidates, key=lambda p: tuple(tasks.index(x) for x in p)))
    before = (list(tasks), list(deps))
    assert schedule_tasks(tasks, deps) == expected
    assert (tasks, deps) == before
''', "FIFO_instead_of_current_priority", "u = heapq.heappop(ready)", "u = ready.pop(0)")
# This realistic mutant uses a FIFO ready queue for both removal and insertion.
TASKS[-1]['mutants'][0]['code'] = TASKS[-1]['mutants'][0]['code'].replace('heapq.heappush(ready, v)', 'ready.append(v)')


add(6, "recursive_json_patch", "merge_patch", r'''
实现 Python 函数 `merge_patch(base, patch)`。两个参数的根节点都是字典，内部是 JSON 风格值（字符串键的字典、列表、字符串、数值、布尔值、None）。先保留 base 的内容，再处理 patch 的每个键：值为 None 时删除该键，键不存在则忽略；值为字典时递归应用同一规则，base 对应值不是字典或不存在时以空字典开始；其他类型（包括列表）直接整体替换。仅 patch 中的 None 表示删除，base 原有且未被修改的 None 必须保留。返回全新的深拷贝，不得修改任一输入；返回值中的可变对象也不能与任一输入共享。只能使用标准库。
公开例子：
`merge_patch({'a': {'x': 1, 'y': 2}, 'b': [1]}, {'a': {'x': None, 'z': 3}, 'b': [2]}) == {'a': {'y': 2, 'z': 3}, 'b': [2]}`
`merge_patch({'a': 7, 'keep': None}, {'a': {'x': None, 'y': 1}}) == {'a': {'y': 1}, 'keep': None}`
请给出完整函数实现及必要的导入。
''', '''
import copy

def merge_patch(base, patch):
    def apply(old, changes):
        result = copy.deepcopy(old) if isinstance(old, dict) else {}
        for key, value in changes.items():
            if value is None:
                result.pop(key, None)
            elif isinstance(value, dict):
                result[key] = apply(result.get(key), value)
            else:
                result[key] = copy.deepcopy(value)
        return result
    return apply(base, patch)
''', '''
import copy
assert merge_patch({}, {}) == {}
assert merge_patch({'a': 1}, {}) == {'a': 1}
assert merge_patch({}, {'a': 1}) == {'a': 1}
assert merge_patch({'a': 1}, {'a': None}) == {}
assert merge_patch({}, {'a': None}) == {}
assert merge_patch({'a': None}, {}) == {'a': None}
assert merge_patch({'a': {'x': 1, 'y': 2}, 'b': [1]}, {'a': {'x': None, 'z': 3}, 'b': [2]}) == {'a': {'y': 2, 'z': 3}, 'b': [2]}
assert merge_patch({'a': 7, 'keep': None}, {'a': {'x': None, 'y': 1}}) == {'a': {'y': 1}, 'keep': None}
assert merge_patch({'a': [1, 2]}, {'a': {}}) == {'a': {}}
assert merge_patch({'a': {'x': 1}}, {'a': {}}) == {'a': {'x': 1}}
assert merge_patch({'a': {'x': 1}}, {'a': []}) == {'a': []}
assert merge_patch({}, {'x': {'y': {'z': None}}}) == {'x': {'y': {}}}
assert merge_patch({'a': True}, {'a': False}) == {'a': False}
assert merge_patch({'a': 1}, {'a': 0}) == {'a': 0}
base = {'keep': [{'deep': [1]}], 'replace': [{'old': 2}], 'nested': {'x': [3]}}
patch = {'replace': [{'new': [4]}], 'nested': {'y': [5]}}
base_before, patch_before = copy.deepcopy(base), copy.deepcopy(patch)
result = merge_patch(base, patch)
assert base == base_before and patch == patch_before
result['keep'][0]['deep'].append(9)
result['replace'][0]['new'].append(9)
result['nested']['x'].append(9)
result['nested']['y'].append(9)
assert base == base_before and patch == patch_before
base['keep'][0]['deep'].append(8)
patch['replace'][0]['new'].append(8)
assert result['keep'][0]['deep'] == [1, 9]
assert result['replace'][0]['new'] == [4, 9]
''', "shallow_copy_base_aliases_nested_values", "copy.deepcopy(old) if isinstance(old, dict) else {}", "dict(old) if isinstance(old, dict) else {}")


add(7, "lexical_path_normalization", "normalize_path", r'''
实现 Python 函数 `normalize_path(path)`，只进行 POSIX 风格的字符串路径规范化，不访问文件系统。一个或多个 '/' 都是分隔符；以 '/' 开头的路径是绝对路径。忽略空段和 '.' 段；'..' 抵消前面最近的一个普通段。绝对路径不允许越过根目录，越过的 '..' 忽略；相对路径中无法抵消的 '..' 必须保留，而且 '..' 不能与另一个 '..' 抵消。结果段间仅保留一个 '/'，删除末尾 '/'，绝对空结果是 '/'，相对空结果是 '.'。恰好两个前导 '/' 也当作普通根目录。反斜杠、空格和其他字符只是普通文件名字符，不展开 '~'。只能使用标准库。
公开例子：
`normalize_path('/a//b/../c/.') == '/a/c'`
`normalize_path('../../a/../b') == '../../b'`
请给出完整函数实现及必要的导入。
''', '''
def normalize_path(path):
    absolute = path.startswith('/')
    parts = []
    for part in path.split('/'):
        if part in ('', '.'):
            continue
        if part == '..':
            if parts and parts[-1] != '..':
                parts.pop()
            elif not absolute:
                parts.append('..')
        else:
            parts.append(part)
    if absolute:
        return '/' + '/'.join(parts)
    return '/'.join(parts) or '.'
''', r'''
cases = {
    '': '.', '.': '.', './': '.', '/': '/', '////': '/',
    '/a//b/../c/.': '/a/c', '../../a/../b': '../../b',
    '../..': '../..', 'a/../../b': '../b', '../../../': '../../..',
    '/../../a': '/a', '/a/../../b': '/b', '//server//x': '/server/x',
    'a/b/..': 'a', 'a/./b/../..': '.', 'a/../..': '..',
    '/a/b/../../..': '/', '.../..hidden': '.../..hidden',
    ' /a/..': ' ', '~//x': '~/x', r'a\b/..': '.',
    '甲/乙/../丙/': '甲/丙', '../a/../../c': '../../c',
}
for source, expected in cases.items():
    assert normalize_path(source) == expected, (source, normalize_path(source))
    assert normalize_path(expected) == expected
import random
import posixpath
rng = random.Random(107)
for _ in range(200):
    source = ('/' if rng.choice([True, False]) else '') + '/'.join(rng.choice(['a', 'b', '.', '..', '']) for _ in range(rng.randrange(15)))
    # This specification intentionally collapses the POSIX special double slash.
    expected = posixpath.normpath(source)
    if expected.startswith('//'):
        expected = '/' + expected.lstrip('/')
    assert normalize_path(source) == expected
''', "parent_segments_cancel_each_other", "if parts and parts[-1] != '..':", "if parts:")


add(8, "sliding_window_median", "rolling_median", r'''
实现 Python 函数 `rolling_median(values, k)`。values 是整数列表，k 是整数窗口宽度。对每个连续的、长度恰好为 k 的窗口，按从左到右的窗口顺序返回中位数列表。奇数长度取排序后的中间元素，偶数长度取中间两个元素的算术平均，所有结果使用 float。k <= 0 抛出 ValueError；k > len(values) 返回 []（包括空输入且 k > 0）。重复值和负数正常参与排序；不得修改输入。只能使用标准库，不要求特殊的渐进复杂度。
公开例子：
`rolling_median([1, 5, 2, 4], 3) == [2.0, 4.0]`
`rolling_median([1, 2, 8, 3], 2) == [1.5, 5.0, 5.5]`
请给出完整函数实现及必要的导入。
''', '''
import bisect

def rolling_median(values, k):
    if k <= 0:
        raise ValueError("window must be positive")
    if k > len(values):
        return []
    window = sorted(values[:k])
    result = []
    for start in range(len(values) - k + 1):
        if k % 2:
            median = float(window[k // 2])
        else:
            median = (window[k // 2 - 1] + window[k // 2]) / 2.0
        result.append(median)
        if start + k < len(values):
            window.pop(bisect.bisect_left(window, values[start]))
            bisect.insort(window, values[start + k])
    return result
''', '''
import random
assert rolling_median([], 1) == []
assert rolling_median([1], 2) == []
assert rolling_median([7], 1) == [7.0]
assert rolling_median([1, 5, 2, 4], 3) == [2.0, 4.0]
assert rolling_median([1, 2, 8, 3], 2) == [1.5, 5.0, 5.5]
assert rolling_median([5, 5, 5, 5], 2) == [5.0, 5.0, 5.0]
assert rolling_median([-9, -2, -4], 2) == [-5.5, -3.0]
assert rolling_median([9, 1, 2, 8], 4) == [5.0]
assert rolling_median([9, 2, 9, 1], 1) == [9.0, 2.0, 9.0, 1.0]
assert rolling_median([0, 0, 1, 0, 0], 3) == [0.0, 0.0, 0.0]
assert rolling_median([10**12, -10**12], 2) == [0.0]
for k in [0, -1, -10]:
    try:
        rolling_median([], k)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid window accepted")
rng = random.Random(108)
for _ in range(200):
    values = [rng.randrange(-20, 21) for _ in range(rng.randrange(30))]
    before = list(values)
    k = rng.randrange(1, 35)
    expected = []
    for start in range(len(values) - k + 1):
        segment = sorted(values[start:start+k])
        expected.append(float(segment[k // 2]) if k % 2 else (segment[k // 2 - 1] + segment[k // 2]) / 2)
    actual = rolling_median(values, k)
    assert actual == expected
    assert all(isinstance(x, float) for x in actual)
    assert values == before
''', "even_window_uses_upper_middle", "(window[k // 2 - 1] + window[k // 2]) / 2.0", "float(window[k // 2])")


add(9, "event_sessionization", "sessionize", r'''
实现 Python 函数 `sessionize(events, gap)`。events 是 `(user, timestamp)` 二元组列表，user 是字符串，timestamp 是整数；输入可能乱序且可以有重复事件。gap 是非负整数，负数时抛出 ValueError。先对每个用户的事件按时间排序；同一用户相邻两次事件的时间差 <= gap 时属于同一个会话，否则开始新会话。这是相邻事件链式连接，不是与会话起点比较。返回 `(user, start, end, count)` 元组列表，start/end 分别为会话最早/最晚事件时间（均包含），count 计入重复事件。结果先按 user 的 Python 字符串顺序，再按 start 升序排列；空输入返回 []，不得修改输入。只能使用标准库。
公开例子：
`sessionize([('b', 5), ('a', 0), ('a', 4), ('a', 8), ('a', 20)], 4) == [('a', 0, 8, 3), ('a', 20, 20, 1), ('b', 5, 5, 1)]`
`sessionize([('u', 2), ('u', 2), ('u', 3)], 0) == [('u', 2, 2, 2), ('u', 3, 3, 1)]`
请给出完整函数实现及必要的导入。
''', '''
def sessionize(events, gap):
    if gap < 0:
        raise ValueError("negative gap")
    result = []
    for user, time in sorted(events):
        if result and result[-1][0] == user and time - result[-1][2] <= gap:
            old_user, start, _, count = result[-1]
            result[-1] = (old_user, start, time, count + 1)
        else:
            result.append((user, time, time, 1))
    return result
''', '''
assert sessionize([], 0) == []
assert sessionize([('u', 1)], 0) == [('u', 1, 1, 1)]
assert sessionize([('b', 5), ('a', 0), ('a', 4), ('a', 8), ('a', 20)], 4) == [('a', 0, 8, 3), ('a', 20, 20, 1), ('b', 5, 5, 1)]
assert sessionize([('u', 2), ('u', 2), ('u', 3)], 0) == [('u', 2, 2, 2), ('u', 3, 3, 1)]
assert sessionize([('u', 0), ('u', 5)], 5) == [('u', 0, 5, 2)]
assert sessionize([('u', 0), ('u', 6)], 5) == [('u', 0, 0, 1), ('u', 6, 6, 1)]
assert sessionize([('u', 9), ('u', 3), ('u', 6), ('u', 0)], 3) == [('u', 0, 9, 4)]
assert sessionize([('a', 1), ('b', 1), ('a', 2), ('b', 2)], 1) == [('a', 1, 2, 2), ('b', 1, 2, 2)]
assert sessionize([('u', -5), ('u', -2), ('u', 1)], 3) == [('u', -5, 1, 3)]
assert sessionize([('', 0), ('Z', 0), ('a', 0)], 0) == [('', 0, 0, 1), ('Z', 0, 0, 1), ('a', 0, 0, 1)]
assert sessionize([('u', 4)] * 6, 0) == [('u', 4, 4, 6)]
assert sessionize([('u', -10**30), ('u', 10**30)], 2*10**30) == [('u', -10**30, 10**30, 2)]
for events in [[], [('u', 1)]]:
    try:
        sessionize(events, -1)
    except ValueError:
        pass
    else:
        raise AssertionError("negative gap accepted")
import random
rng = random.Random(109)
for _ in range(100):
    events = [(rng.choice(['a', 'b', 'c']), rng.randrange(-10, 11)) for _ in range(rng.randrange(30))]
    snapshot = list(events)
    gap = rng.randrange(6)
    expected = []
    for user in sorted({u for u, t in events}):
        times = sorted(t for u, t in events if u == user)
        starts = [0] + [i for i in range(1, len(times)) if times[i] - times[i - 1] > gap] + [len(times)]
        for lo, hi in zip(starts, starts[1:]):
            expected.append((user, times[lo], times[hi - 1], hi - lo))
    assert sessionize(events, gap) == expected
    assert events == snapshot
''', "gap_boundary_is_exclusive", "time - result[-1][2] <= gap", "time - result[-1][2] < gap")


add(10, "quoted_key_value_parser", "parse_assignments", r'''
实现 Python 函数 `parse_assignments(text)`，解析以空白分隔的 key=value 条目，返回字符串到字符串的字典。空白以 str.isspace() 定义；开头结尾允许空白；空输入返回 {}。键必须匹配 ASCII `[A-Za-z_][A-Za-z0-9_]*`，键和等号之间不允许空白。值有两种形式：(1) 以单引号或双引号开始，直到相同引号结束，内部可以有空白，另一种引号当作普通字符，允许空值；(2) 不以引号开始的非空值，直到未转义的空白或输入结尾结束，其中不允许未转义的单/双引号。两种值内，反斜杠都转义紧跟的任意一个字符，即移除反斜杠并保留后一个字符；它不是 '\n' 等特殊字符映射。引号闭合后只能紧跟空白或输入结束。未闭合引号、孤立末尾反斜杠、非法键、缺少等号、空的未引号值、重复键或其他语法错误均抛出 ValueError。值中的额外等号是普通字符。只能使用标准库。
公开例子（Python 字符串表示法）：
`parse_assignments('a=1 name="Ada Lovelace" empty=\'\'') == {'a': '1', 'name': 'Ada Lovelace', 'empty': ''}`
`parse_assignments(r'path=a\ b flag=x=y') == {'path': 'a b', 'flag': 'x=y'}`
请给出完整函数实现及必要的导入。
''', r'''
import re

def parse_assignments(text):
    result, i, n = {}, 0, len(text)
    while True:
        while i < n and text[i].isspace():
            i += 1
        if i == n:
            return result
        start = i
        while i < n and text[i] != '=' and not text[i].isspace():
            i += 1
        key = text[start:i]
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key) or i == n or text[i] != '=':
            raise ValueError("invalid key or assignment")
        if key in result:
            raise ValueError("duplicate key")
        i += 1
        if i == n or text[i].isspace():
            raise ValueError("missing value")
        quote = text[i] if text[i] in "\"'" else None
        if quote is not None:
            i += 1
        value, closed = [], quote is None
        while i < n:
            char = text[i]
            if char == chr(92):
                if i + 1 == n:
                    raise ValueError("dangling escape")
                value.append(text[i + 1])
                i += 2
            elif quote is not None and char == quote:
                i += 1
                closed = True
                break
            elif quote is None and char.isspace():
                break
            elif quote is None and char in "\"'":
                raise ValueError("quote in bare value")
            else:
                value.append(char)
                i += 1
        if not closed or (i < n and not text[i].isspace()):
            raise ValueError("unterminated quote or missing separator")
        result[key] = ''.join(value)
''', r'''
assert parse_assignments('') == {}
assert parse_assignments(' \t\n ') == {}
assert parse_assignments('a=1 name="Ada Lovelace" empty=\'\'') == {'a': '1', 'name': 'Ada Lovelace', 'empty': ''}
assert parse_assignments(r'path=a\ b flag=x=y') == {'path': 'a b', 'flag': 'x=y'}
assert parse_assignments(' _x9=0\tA=""\n') == {'_x9': '0', 'A': ''}
assert parse_assignments('a="x\ny"') == {'a': 'x\ny'}
assert parse_assignments('a="x\'y"') == {'a': "x'y"}
assert parse_assignments("a='x\"y'") == {'a': 'x"y'}
assert parse_assignments(r'a=\"x\"') == {'a': '"x"'}
assert parse_assignments(r'a="x\"y"') == {'a': 'x"y'}
assert parse_assignments(r'a=x\\y') == {'a': 'x\\y'}
assert parse_assignments(r'a=\n') == {'a': 'n'}
assert parse_assignments('a=甲\u2003b=乙') == {'a': '甲', 'b': '乙'}
assert parse_assignments('a==') == {'a': '='}
assert parse_assignments('a=\\ ') == {'a': ' '}
invalid = ['a', '=x', '1a=x', 'a-b=x', '甲=x', 'a =x', 'a= x', 'a=', 'a=1 a=2', 'a="x', "a='x", 'a="x"b=2', 'a=x"y', 'a=x\'y', 'a=\\', 'a="x\\', 'a=""x', 'a=1 b']
for text in invalid:
    try:
        parse_assignments(text)
    except ValueError:
        pass
    else:
        raise AssertionError(('invalid input accepted', text))
import random
rng = random.Random(110)
for _ in range(100):
    expected = {'key_' + str(i): ''.join(rng.choice('ab =\n\t\\\"\'甲') for _ in range(rng.randrange(12))) for i in range(rng.randrange(8))}
    encoded = []
    for key, value in expected.items():
        quote = rng.choice(['"', "'"])
        encoded.append(key + '=' + quote + ''.join('\\' + c if c in (quote, '\\') else c for c in value) + quote)
    assert parse_assignments(' \t' + '\n'.join(encoded) + ' ') == expected
''', "silently_overwrite_duplicate_keys", "if key in result:", "if False:")


add(11, "exact_largest_remainder_allocation", "allocate_units", r'''
实现 Python 函数 `allocate_units(total, weights)`，用最大余数法把 total 个不可分割单位按权重分配。total 是非负整数，weights 是非负整数列表；任何负数抛出 ValueError。权重总和 S > 0 时，先分配每项的精确配额 total*weight/S 的下取整，再将剩余单位按配额的小数余数从大到小分配，每项至多额外一个；余数相同优先原列表中索引较小的项。返回与 weights 等长的整数列表，不能修改输入。total 为 0 时返回全 0（空列表也允许）；total > 0 而 S == 0（包括空列表）时抛出 ValueError。必须对任意大的 Python 整数保持精确，不能依赖浮点近似。只能使用标准库。
公开例子：
`allocate_units(5, [1, 1, 1]) == [2, 2, 1]`
`allocate_units(7, [0, 2, 1]) == [0, 5, 2]`
请给出完整函数实现及必要的导入。
''', '''
def allocate_units(total, weights):
    if total < 0 or any(weight < 0 for weight in weights):
        raise ValueError("negative amount or weight")
    if total == 0:
        return [0] * len(weights)
    denominator = sum(weights)
    if denominator == 0:
        raise ValueError("no positive weight")
    result, remainders = [], []
    for weight in weights:
        units, remainder = divmod(total * weight, denominator)
        result.append(units)
        remainders.append(remainder)
    ordering = sorted(range(len(weights)), key=lambda i: (-remainders[i], i))
    for i in ordering[:total - sum(result)]:
        result[i] += 1
    return result
''', '''
from fractions import Fraction
import random
assert allocate_units(0, []) == []
assert allocate_units(0, [0, 0]) == [0, 0]
assert allocate_units(0, [1, 2]) == [0, 0]
assert allocate_units(5, [1, 1, 1]) == [2, 2, 1]
assert allocate_units(7, [0, 2, 1]) == [0, 5, 2]
assert allocate_units(1, [1, 1, 1]) == [1, 0, 0]
assert allocate_units(2, [1, 1, 1]) == [1, 1, 0]
assert allocate_units(6, [1, 1, 1]) == [2, 2, 2]
assert allocate_units(4, [0, 0, 1]) == [0, 0, 4]
assert allocate_units(9, [7]) == [9]
assert allocate_units(2**60 + 1, [1, 1]) == [2**59 + 1, 2**59]
assert allocate_units(1, [2**60, 2**60 + 1]) == [0, 1]
for total, weights in [(-1, [1]), (0, [-1]), (1, []), (2, [0, 0]), (1, [1, -1])]:
    try:
        allocate_units(total, weights)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid allocation accepted")
rng = random.Random(111)
for _ in range(200):
    weights = [rng.randrange(20) for _ in range(rng.randrange(1, 15))]
    if sum(weights) == 0:
        weights[0] = 1
    total = rng.randrange(1000)
    before = list(weights)
    quotas = [Fraction(total * weight, sum(weights)) for weight in weights]
    expected = [quota.numerator // quota.denominator for quota in quotas]
    candidates = sorted(range(len(weights)), key=lambda i: (-(quotas[i] - expected[i]), i))
    for i in candidates[:total - sum(expected)]:
        expected[i] += 1
    assert allocate_units(total, weights) == expected
    assert weights == before
''', "later_index_wins_remainder_ties", "key=lambda i: (-remainders[i], i)", "key=lambda i: (-remainders[i], -i)")


add(12, "semantic_version_precedence", "compare_versions", r'''
实现 Python 函数 `compare_versions(a, b)`，按下列明确规则比较两个版本字符串，分别返回 -1、0、1。合法语法为 `MAJOR.MINOR.PATCH[-PRERELEASE][+BUILD]`，三个核心编号都是非负 ASCII 十进制整数，除单个 '0' 外不得有前导零；必须恰好三个核心编号。不允许空白或其他额外字符。PRERELEASE 和 BUILD 各由一个或多个以 '.' 分隔的非空标识符组成，标识符仅允许 ASCII 字母、数字和 '-'；纯数字的 PRERELEASE 标识符除 '0' 外不得有前导零，BUILD 数字允许前导零。BUILD 完全不影响优先级，但仍须校验合法性。先将三个核心编号按整数元组比较；核心相同时，无 PRERELEASE 的版本高于有 PRERELEASE 的版本；两个预发布逐标识符比较：纯数字按整数比较，数字低于非数字，非数字按 ASCII 字典序比较；相同前缀时标识符更少者更低。任一字符串非法均抛出 ValueError。只能使用标准库。
公开例子：
`compare_versions('1.0.0-alpha.2', '1.0.0-alpha.10') == -1`
`compare_versions('2.1.0+001', '2.1.0+build.7') == 0`
请给出完整函数实现及必要的导入。
''', r'''
import re

def compare_versions(a, b):
    pattern = re.compile(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?')
    def parse(text):
        match = pattern.fullmatch(text)
        if match is None:
            raise ValueError("invalid version")
        core = tuple(int(match.group(i)) for i in (1, 2, 3))
        prerelease = None if match.group(4) is None else match.group(4).split('.')
        if prerelease is not None:
            for part in prerelease:
                if part.isdigit() and len(part) > 1 and part.startswith('0'):
                    raise ValueError("leading zero in prerelease")
        return core, prerelease
    core_a, pre_a = parse(a)
    core_b, pre_b = parse(b)
    if core_a != core_b:
        return (core_a > core_b) - (core_a < core_b)
    if pre_a is None or pre_b is None:
        return (pre_a is None) - (pre_b is None)
    for x, y in zip(pre_a, pre_b):
        if x == y:
            continue
        x_num, y_num = x.isdigit(), y.isdigit()
        if x_num and y_num:
            return (int(x) > int(y)) - (int(x) < int(y))
        if x_num != y_num:
            return -1 if x_num else 1
        return (x > y) - (x < y)
    return (len(pre_a) > len(pre_b)) - (len(pre_a) < len(pre_b))
''', '''
assert compare_versions('1.0.0-alpha.2', '1.0.0-alpha.10') == -1
assert compare_versions('2.1.0+001', '2.1.0+build.7') == 0
assert compare_versions('1.0.0', '1.0.0') == 0
assert compare_versions('2.0.0-alpha', '1.999.999') == 1
assert compare_versions('1.10.0', '1.2.0') == 1
assert compare_versions('1.0.0-1', '1.0.0-a') == -1
assert compare_versions('1.0.0-A', '1.0.0-a') == -1
assert compare_versions('1.0.0-01a', '1.0.0-1') == 1
assert compare_versions('0.0.0-0', '0.0.0-0.0') == -1
assert compare_versions('1.0.0-a+b', '1.0.0-a+c') == 0
assert compare_versions('1.0.0--', '1.0.0-a') == -1
assert compare_versions('999999999999999999999.0.0', '2.0.0') == 1
chain = ['1.0.0-alpha', '1.0.0-alpha.1', '1.0.0-alpha.beta', '1.0.0-beta', '1.0.0-beta.2', '1.0.0-beta.11', '1.0.0-rc.1', '1.0.0']
for i, left in enumerate(chain):
    for j, right in enumerate(chain):
        assert compare_versions(left, right) == (i > j) - (i < j)
invalid = ['', '1', '1.2', '1.2.3.4', '01.2.3', '1.02.3', '1.2.03', '1.2.3-', '1.2.3+', '1.2.3-a..b', '1.2.3+a..b', '1.2.3-01', '1.2.3-a.01', '1.2.3+a_', '1.2.3 a', ' 1.2.3', '1.2.3\\n', '١.2.3', '1.2.3-甲', '1.2.3+x+y', 'v1.2.3']
for version in invalid:
    for left, right in [(version, '1.0.0'), ('1.0.0', version)]:
        try:
            compare_versions(left, right)
        except ValueError:
            pass
        else:
            raise AssertionError(('invalid version accepted', version))
''', "numeric_prerelease_compared_lexicographically", "return (int(x) > int(y)) - (int(x) < int(y))", "return (x > y) - (x < y)")


add(13, "grid_bfs_with_resource_budget", "shortest_path_with_breaks", r'''
实现 Python 函数 `shortest_path_with_breaks(grid, max_breaks)`。grid 是非空矩形二维列表，每个格子是整数 0（可通行）或 1（障碍）；max_breaks 是非负整数。每一步可向上、下、左、右移动一格，不能越界；经过障碍格时需要消耗一个清除额度，最多可清除 max_breaks 个障碍格。求从左上角 `(0, 0)` 到右下角 `(rows-1, cols-1)` 的最少移动步数，起点本身不算一步，但如果起点是障碍也必须消耗一个额度，终点同理。无法到达返回 -1。空 grid、空行、非矩形或 max_breaks < 0 时抛出 ValueError；其他类型和值保证合法。不允许修改 grid，只能使用标准库。
公开例子：
`shortest_path_with_breaks([[0, 1, 0], [0, 1, 0], [0, 0, 0]], 0) == 4`
`shortest_path_with_breaks([[1]], 0) == -1`，而 `shortest_path_with_breaks([[1]], 1) == 0`
请给出完整函数实现及必要的导入。
''', '''
from collections import deque

def shortest_path_with_breaks(grid, max_breaks):
    if max_breaks < 0 or not grid or not grid[0] or any(len(row) != len(grid[0]) for row in grid):
        raise ValueError("invalid grid or budget")
    rows, cols = len(grid), len(grid[0])
    used = grid[0][0]
    if used > max_breaks:
        return -1
    pending = deque([(0, 0, used, 0)])
    seen = {(0, 0, used)}
    while pending:
        row, col, used, distance = pending.popleft()
        if (row, col) == (rows - 1, cols - 1):
            return distance
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = row + dr, col + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                next_used = used + grid[nr][nc]
                state = (nr, nc, next_used)
                if next_used <= max_breaks and state not in seen:
                    seen.add(state)
                    pending.append((nr, nc, next_used, distance + 1))
    return -1
''', '''
import itertools
import random
from collections import deque
assert shortest_path_with_breaks([[0]], 0) == 0
assert shortest_path_with_breaks([[1]], 0) == -1
assert shortest_path_with_breaks([[1]], 1) == 0
assert shortest_path_with_breaks([[0, 1, 0], [0, 1, 0], [0, 0, 0]], 0) == 4
assert shortest_path_with_breaks([[0, 1, 0]], 0) == -1
assert shortest_path_with_breaks([[0, 1, 0]], 1) == 2
assert shortest_path_with_breaks([[0], [1], [0]], 1) == 2
assert shortest_path_with_breaks([[1, 1]], 1) == -1
assert shortest_path_with_breaks([[1, 1]], 2) == 1
assert shortest_path_with_breaks([[0, 1], [1, 0]], 0) == -1
assert shortest_path_with_breaks([[0, 1], [1, 0]], 1) == 2
assert shortest_path_with_breaks([[0, 1], [1, 1]], 1) == -1
assert shortest_path_with_breaks([[0, 1], [1, 1]], 2) == 2
for grid, budget in [([], 0), ([[]], 0), ([[0], []], 0), ([[0], [0, 0]], 0), ([[0]], -1)]:
    try:
        shortest_path_with_breaks(grid, budget)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid grid accepted")
# Independent oracle: enumerate which wall cells are permanently removed,
# then perform ordinary BFS on each resulting board.
def oracle(board, budget):
    rows, cols = len(board), len(board[0])
    walls = [(r, c) for r in range(rows) for c in range(cols) if board[r][c]]
    best = None
    for size in range(min(budget, len(walls)) + 1):
        for picked in itertools.combinations(walls, size):
            removed = set(picked)
            if board[0][0] and (0, 0) not in removed:
                continue
            q, seen = deque([((0, 0), 0)]), {(0, 0)}
            while q:
                (r, c), distance = q.popleft()
                if (r, c) == (rows - 1, cols - 1):
                    best = distance if best is None else min(best, distance)
                    break
                for nr, nc in [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]:
                    if 0 <= nr < rows and 0 <= nc < cols and (nr, nc) not in seen and (not board[nr][nc] or (nr, nc) in removed):
                        seen.add((nr, nc))
                        q.append(((nr, nc), distance + 1))
    return -1 if best is None else best
rng = random.Random(113)
for _ in range(65):
    grid = [[rng.randrange(2) for _ in range(3)] for _ in range(3)]
    budget = rng.randrange(4)
    before = [row[:] for row in grid]
    assert shortest_path_with_breaks(grid, budget) == oracle(grid, budget)
    assert grid == before
''', "starting_wall_is_free", "used = grid[0][0]", "used = 0")


add(14, "lru_state_machine", "simulate_lru", r'''
实现 Python 函数 `simulate_lru(capacity, operations)`。capacity 是非负整数，负数抛出 ValueError。operations 是操作元组列表，每项为 `('get', key)` 或 `('put', key, value)`，key 为字符串，value 为整数，操作格式保证合法。模拟初始为空、最多存放 capacity 个键的 LRU 缓存。get 命中时返回对应值，并把该键变为最近使用；未命中返回 None，不改变缓存。put 已有键时更新值并变为最近使用；put 新键时插入为最近使用，若超容量淘汰最久未使用的键。capacity 为 0 时任何内容都不能保留。返回 `(get_results, final_items)`：前者是所有 get 的返回值列表，后者是最终缓存按最久未使用到最近使用排列的 `(key, value)` 元组列表。不得修改 operations，只能使用标准库。
公开例子：
`simulate_lru(2, [('put', 'a', 1), ('put', 'b', 2), ('get', 'a'), ('put', 'c', 3), ('get', 'b')]) == ([1, None], [('a', 1), ('c', 3)])`
`simulate_lru(0, [('put', 'a', 1), ('get', 'a')]) == ([None], [])`
请给出完整函数实现及必要的导入。
''', '''
from collections import OrderedDict

def simulate_lru(capacity, operations):
    if capacity < 0:
        raise ValueError("negative capacity")
    cache, results = OrderedDict(), []
    for operation in operations:
        action, key = operation[:2]
        if action == 'get':
            if key in cache:
                results.append(cache[key])
                cache.move_to_end(key)
            else:
                results.append(None)
        else:
            cache[key] = operation[2]
            cache.move_to_end(key)
            if len(cache) > capacity:
                cache.popitem(last=False)
    return results, list(cache.items())
''', '''
import random
assert simulate_lru(2, []) == ([], [])
assert simulate_lru(0, []) == ([], [])
assert simulate_lru(2, [('get', 'x')]) == ([None], [])
assert simulate_lru(0, [('put', 'a', 1), ('get', 'a')]) == ([None], [])
assert simulate_lru(2, [('put', 'a', 1), ('put', 'b', 2), ('get', 'a'), ('put', 'c', 3), ('get', 'b')]) == ([1, None], [('a', 1), ('c', 3)])
assert simulate_lru(2, [('put', 'a', 1), ('put', 'b', 2), ('put', 'a', 3)]) == ([], [('b', 2), ('a', 3)])
assert simulate_lru(2, [('put', 'a', 1), ('put', 'b', 2), ('put', 'a', 3), ('put', 'c', 4), ('get', 'b')]) == ([None], [('a', 3), ('c', 4)])
assert simulate_lru(1, [('put', 'a', 1), ('put', 'a', 2), ('get', 'a')]) == ([2], [('a', 2)])
assert simulate_lru(1, [('put', 'a', 0), ('get', 'a')]) == ([0], [('a', 0)])
assert simulate_lru(1, [('put', '', -1), ('get', '')]) == ([-1], [('', -1)])
assert simulate_lru(1, [('put', 'a', 1), ('put', 'b', 2), ('get', 'a'), ('get', 'b')]) == ([None, 2], [('b', 2)])
assert simulate_lru(2, [('put', 'a', 1), ('put', 'b', 2), ('get', 'z')]) == ([None], [('a', 1), ('b', 2)])
try:
    simulate_lru(-1, [])
except ValueError:
    pass
else:
    raise AssertionError("negative capacity accepted")
rng = random.Random(114)
for _ in range(150):
    capacity = rng.randrange(5)
    operations = []
    for _ in range(rng.randrange(40)):
        key = rng.choice('abcde')
        operations.append(('get', key) if rng.random() < 0.45 else ('put', key, rng.randrange(-2, 4)))
    items, expected_gets = [], []
    for op in operations:
        index = next((i for i, (key, value) in enumerate(items) if key == op[1]), None)
        if op[0] == 'get':
            if index is None:
                expected_gets.append(None)
            else:
                item = items.pop(index)
                items.append(item)
                expected_gets.append(item[1])
        else:
            if index is not None:
                items.pop(index)
            items.append((op[1], op[2]))
            if len(items) > capacity:
                items.pop(0)
    before = list(operations)
    assert simulate_lru(capacity, operations) == (expected_gets, items)
    assert operations == before
''', "updating_existing_key_does_not_refresh_recency", "cache[key] = operation[2]\n            cache.move_to_end(key)", "cache[key] = operation[2]")


add(15, "nested_delimiters_with_quoted_strings", "bracket_spans", r'''
实现 Python 函数 `bracket_spans(text)`，扫描字符串中 ()、[]、{} 三种括号，支持正确嵌套。返回所有匹配括号的 `(opening_index, closing_index, opening_character)` 元组列表，按 opening_index 升序，索引按 Python 字符串字符索引计算。单引号或双引号开启字符串区域，到相同引号结束；区域内部的所有括号和另一种引号都是普通字符。无论在区域内外，反斜杠都转义紧随的一个字符，被转义字符不具有引号或括号含义。末尾孤立反斜杠、未闭合引号、未闭合左括号、没有对应左括号的右括号或括号类型不匹配，均抛出 ValueError。普通文本和空字符串合法，无匹配括号时返回 []。只使用标准库，不要修改或规范化字符串后再计算索引。
公开例子：
`bracket_spans('a([x])') == [(1, 5, '('), (2, 4, '[')]`
`bracket_spans('"[ignored]"{}') == [(11, 12, '{')]`
请给出完整函数实现及必要的导入。
''', r'''
def bracket_spans(text):
    pairs = {')': '(', ']': '[', '}': '{'}
    stack, result, quote, i = [], [], None, 0
    while i < len(text):
        char = text[i]
        if char == chr(92):
            if i + 1 >= len(text):
                raise ValueError("dangling escape")
            i += 2
            continue
        if quote is not None:
            if char == quote:
                quote = None
        elif char in "\"'":
            quote = char
        elif char in '([{':
            stack.append((char, i))
        elif char in pairs:
            if not stack or pairs[char] != stack[-1][0]:
                raise ValueError("mismatched closing bracket")
            opening, index = stack.pop()
            result.append((index, i, opening))
        i += 1
    if stack or quote is not None:
        raise ValueError("unclosed bracket or quote")
    return sorted(result)
''', r'''
assert bracket_spans('') == []
assert bracket_spans('ordinary text') == []
assert bracket_spans('()') == [(0, 1, '(')]
assert bracket_spans('[]{}()') == [(0, 1, '['), (2, 3, '{'), (4, 5, '(')]
assert bracket_spans('a([x])') == [(1, 5, '('), (2, 4, '[')]
assert bracket_spans('"[ignored]"{}') == [(11, 12, '{')]
assert bracket_spans('({[]})') == [(0, 5, '('), (1, 4, '{'), (2, 3, '[')]
assert bracket_spans('甲(乙[丙])') == [(1, 6, '('), (3, 5, '[')]
assert bracket_spans("'[)]'[]") == [(5, 6, '[')]
assert bracket_spans(r'\(x\)[]') == [(5, 6, '[')]
assert bracket_spans(r'("a\"[b]")') == [(0, 9, '(')]
assert bracket_spans(r'\\()') == [(2, 3, '(')]
assert bracket_spans("\"'[]'\"") == []
assert bracket_spans('(\n)') == [(0, 2, '(')]
invalid = ['(', ')', '[)', '([)]', '(()', '())', '"x', "'x", '\\', 'x\\', '("x)', r'(\))(', '[{}', r'"abc\"']
for source in invalid:
    try:
        bracket_spans(source)
    except ValueError:
        pass
    else:
        raise AssertionError(('invalid text accepted', source))
import random
rng = random.Random(115)
for _ in range(150):
    # Generate balanced nested strings with independently known spans.
    def make(depth):
        if depth == 0 or rng.random() < 0.25:
            return rng.choice(['x', '甲', '"[ignored]"', r'\[']), []
        opening, closing = rng.choice([('(', ')'), ('[', ']'), ('{', '}')])
        content, spans = make(depth - 1)
        text = opening + content + closing
        spans = [(0, len(text) - 1, opening)] + [(a + 1, b + 1, ch) for a, b, ch in spans]
        tail, tail_spans = make(depth - 1)
        return text + tail, spans + [(a + len(text), b + len(text), ch) for a, b, ch in tail_spans]
    text, expected = make(4)
    assert bracket_spans(text) == expected
''', "accept_mismatched_bracket_types", "if not stack or pairs[char] != stack[-1][0]:", "if not stack:")


def verify():
    results = []
    for task in TASKS:
        namespace = {}
        exec(compile(task['reference'], task['id'] + '_reference', 'exec'), namespace)
        exec(compile(task['tests'], task['id'] + '_tests', 'exec'), namespace)
        killed = []
        for mutant in task['mutants']:
            namespace = {}
            try:
                exec(compile(mutant['code'], task['id'] + '_mutant', 'exec'), namespace)
                exec(compile(task['tests'], task['id'] + '_tests', 'exec'), namespace)
            except Exception as error:
                killed.append({'name': mutant['name'], 'exception': type(error).__name__})
            else:
                raise AssertionError((task['id'], mutant['name'], 'SURVIVED'))
        results.append({'id': task['id'], 'reference': 'passed', 'mutants_killed': killed})
        print(task['id'], 'reference passed; mutant killed')
    return results


if __name__ == '__main__':
    results = verify()
    output = pathlib.Path(__file__).parent / 'bench' / 'tasks_a.jsonl'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(''.join(json.dumps(task, ensure_ascii=False) + '\n' for task in TASKS), encoding='utf-8')
    print(f'Wrote {len(TASKS)} tasks to {output}')
