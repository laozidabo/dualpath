"""Validate trusted local references and kill hand-written benchmark mutants.

This is a benchmark construction check, not a sandbox for model-generated code.
Run from any directory with: python /absolute/path/to/validate_tasks_b.py
"""

from __future__ import annotations

import ast
import json
from pathlib import Path


def run(source: str, tests: str, label: str) -> None:
    namespace: dict = {}
    exec(compile(source, label + "_solution", "exec"), namespace)
    exec(compile(tests, label + "_tests", "exec"), namespace)


def main() -> None:
    path = Path(__file__).with_name("tasks_b.jsonl")
    tasks = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    assert [task["id"] for task in tasks] == [f"DP{i:03}" for i in range(16, 31)]
    reference_passes = 0
    mutants_killed = 0
    for task in tasks:
        required = {"id", "category", "entry_point", "prompt", "reference", "tests", "mutants"}
        assert set(task) == required, task["id"]
        assert task["mutants"], task["id"]
        assert_count = sum(isinstance(node, ast.Assert) for node in ast.walk(ast.parse(task["tests"])))
        assert assert_count >= 10, (task["id"], assert_count)
        run(task["reference"], task["tests"], task["id"] + "_reference")
        reference_passes += 1
        for mutant in task["mutants"]:
            # Syntax errors do not count as a killed behavioral mutant.
            compile(mutant["code"], task["id"] + "_mutant", "exec")
            try:
                run(mutant["code"], task["tests"], task["id"] + "_mutant")
            except Exception as error:
                mutants_killed += 1
                print(f"{task['id']}: reference PASS; mutant KILLED ({type(error).__name__}); {assert_count} static asserts")
            else:
                raise AssertionError(f"{task['id']}: mutant survived: {mutant['name']}")
    print(f"Validated: {reference_passes} references passed; {mutants_killed} mutants killed.")


if __name__ == "__main__":
    main()
