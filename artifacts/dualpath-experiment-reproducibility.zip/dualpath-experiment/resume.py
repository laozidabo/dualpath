"""Recover infrastructure-interrupted pairs without changing the frozen protocol."""
from __future__ import annotations

import asyncio
import fcntl
import getpass
import json
from pathlib import Path
import random
import time

import experiment as e

ROOT = Path(__file__).resolve().parent


async def recover_pair(api, task, repeat, out):
    tid = task["id"]
    incomplete_path = out / "incomplete" / f"{tid}_r{repeat}.json"
    destination = out / "results" / f"{tid}_r{repeat}.json"
    if not incomplete_path.exists():
        return False
    result = json.loads(incomplete_path.read_text())
    saved = json.loads((out / "drafts" / f"{tid}_r{repeat}.json").read_text())
    initial, initial_record = saved["text"], saved["record"]
    prompt = task["prompt"] + e.CODE_RULE
    calls = [json.loads(p.read_text()) for p in (out / "calls").glob("*.json")]
    groups = [g for g in ("self_refine", "dualpath") if "infrastructure_error" in result["groups"].get(g, {})]
    if not groups:
        raise RuntimeError(f"No recoverable infrastructure error in {tid}_r{repeat}")

    async def condition(group):
        model = e.MeasuredModel(api, tid, repeat, group, initial=initial if group == "dualpath" else None)
        started = time.perf_counter()
        try:
            if group == "dualpath":
                raw = await e.DualPath(model=model, search=e.NoSearch(), max_problems=5).run(prompt)
                text, extra = raw.final_output, {"dualpath_record": raw.to_dict()}
            else:
                text, extra = await e.self_refine(model, prompt, initial), {}
            await model.drain()
            previous = [r for r in calls if r.get("task_id") == tid and r.get("repeat") == repeat and r.get("group") == group]
            return {
                "output": text,
                **extra,
                "metrics": e.metrics([initial_record] + previous + model.records),
                "additional_seconds": time.perf_counter() - started,
                "total_wall_seconds": initial_record["elapsed_seconds"] + time.perf_counter() - started,
                "recovered_from_infrastructure": True,
            }
        except (ValueError, KeyError, TypeError) as error:
            await model.drain()
            previous = [r for r in calls if r.get("task_id") == tid and r.get("repeat") == repeat and r.get("group") == group]
            return {
                "output": "",
                "method_error": type(error).__name__ + ": " + str(error)[:180],
                "metrics": e.metrics([initial_record] + previous + model.records),
                "additional_seconds": time.perf_counter() - started,
                "recovered_from_infrastructure": True,
            }
        finally:
            await model.drain()

    computed = await asyncio.gather(*(condition(g) for g in groups), return_exceptions=True)
    fatal = None
    for group, value in zip(groups, computed):
        if isinstance(value, BaseException):
            fatal = value
            result["groups"][group] = {"infrastructure_error": type(value).__name__}
        else:
            result["groups"][group] = value
    if fatal:
        e.write_json(incomplete_path, result)
        raise fatal
    for group, row in result["groups"].items():
        row["grade"] = await asyncio.to_thread(e.grade, e.extract_code(row["output"]), task["tests"], timeout=8)
        if row["grade"]["status"] == "infrastructure_error":
            e.write_json(incomplete_path, result)
            raise RuntimeError("Grader infrastructure failure")
    e.write_json(destination, result)
    incomplete_path.unlink()
    statuses = " ".join(f"{g}={r['grade']['status']}" for g, r in result["groups"].items())
    print(f"Recovered {tid} r{repeat}: {statuses}; conservative spend={api.budget.spent:.4f} CNY", flush=True)
    return True


async def run():
    out = ROOT / "runs/pilot"
    config = json.loads((out / "protocol.json").read_text())
    ts = e.tasks()
    if config["dataset_sha256"] != e.digest(ts):
        raise ValueError("Frozen dataset does not match")
    for name, expected in config["harness_sha256"].items():
        if e.hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f"Frozen harness changed: {name}")
    run_lock = (out / ".run.lock").open("a")
    fcntl.flock(run_lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    oldcalls = [json.loads(p.read_text()) for p in (out / "calls").glob("*.json")]
    if any(r.get("status") not in {"ok", "error"} for r in oldcalls):
        raise RuntimeError("Pending or unknown API calls exist; inspect accounting before resuming")
    spent = sum(r.get("cost_peak_cny", r.get("reserved_cny", 0)) for r in oldcalls)
    key = getpass.getpass("DeepSeek API key (hidden, memory only): ")
    if not key:
        raise ValueError("No API key configured")
    api = e.API(key.strip(), config, out, spent)
    balance = await asyncio.to_thread(api.request, "/user/balance")
    if not balance.get("is_available"):
        raise RuntimeError("DeepSeek account has no available balance")
    by_id = {task["id"]: task for task in ts}
    for path in sorted((out / "incomplete").glob("*.json")):
        row = json.loads(path.read_text())
        await recover_pair(api, by_id[row["task_id"]], row["repeat"], out)
    print("Recovery complete; continuing the frozen experiment.", flush=True)
    jobs = [(task, repeat) for repeat in range(1, config["repeats"] + 1) for task in ts]
    random.Random(config["seed"]).shuffle(jobs)
    stopped = None
    for start in range(0, len(jobs), config["task_concurrency"]):
        batch = jobs[start:start + config["task_concurrency"]]
        values = await asyncio.gather(*(e.run_task(api, task, repeat, out) for task, repeat in batch), return_exceptions=True)
        failures = [v for v in values if isinstance(v, BaseException)]
        if failures:
            stopped = type(failures[0]).__name__ + ": " + str(failures[0])[:200]
            print("Run stopped: " + stopped, flush=True)
            break
    e.write_json(out / "run_status.json", {"stopped_reason": stopped, "conservative_spend_cny": api.budget.spent, "outstanding_reserved_cny": api.budget.reserved, "completed_records": len(list((out / "results").glob("*.json"))), "planned_records": config["task_count"] * config["repeats"]})
    e.summarize(out)


if __name__ == "__main__":
    asyncio.run(run())
