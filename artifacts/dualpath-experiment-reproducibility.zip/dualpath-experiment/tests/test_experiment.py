import asyncio
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import experiment as e


class AccountingTests(unittest.IsolatedAsyncioTestCase):
    async def test_concurrent_reservations_cannot_overspend(self):
        budget = e.Budget(.10)
        results = await asyncio.gather(*(budget.reserve(.03) for _ in range(5)), return_exceptions=True)
        self.assertEqual(sum(isinstance(x, e.BudgetExceeded) for x in results), 2)
        self.assertAlmostEqual(budget.reserved, .09)
        await budget.settle(.03, .01)
        self.assertAlmostEqual(budget.spent + budget.reserved, .07)
        await budget.reserve(.03)
        with self.assertRaises(e.BudgetExceeded):
            await budget.reserve(.001)

    def test_prices_and_missing_usage(self):
        usage = {"prompt_tokens": 1_000_000, "prompt_cache_hit_tokens": 250_000, "completion_tokens": 1_000_000}
        self.assertAlmostEqual(e.usage_cost(usage), 9.51)
        self.assertAlmostEqual(e.usage_cost(usage, False), 4.755)
        with self.assertRaises(e.AccountingError):
            e.usage_cost({})

    def test_paired_statistics(self):
        self.assertEqual(e.exact_paired_p(0, 0), 1)
        self.assertEqual(e.exact_paired_p(6, 0), .03125)
        self.assertEqual(e.exact_paired_p(2, 2), 1)
        low, high = e.wilson(30, 30)
        self.assertAlmostEqual(low, .8864866068260312)
        self.assertAlmostEqual(high, 1)


CONFIG = {"model": "fake", "temperature": .2, "max_tokens_per_call": 2048,
          "spending_guard_cny": 9.5, "api_concurrency": 6}


class FakeAPI(e.API):
    def request(self, endpoint, payload=None):
        self.assert_pending = any(json.loads(p.read_text())["status"] == "pending" for p in (self.output / "calls").glob("*.json"))
        if not self.assert_pending:
            raise AssertionError("Request sent before durable reservation")
        system = payload["messages"][0]["content"]
        if "[ERROR_DISCOVER]" in system:
            content = json.dumps([{"title": str(i), "description": "case", "exploration": "edge"} for i in range(5)])
        elif "[ERROR_PROBABILITY]" in system:
            content = '{"probability":0.2,"reasoning":"test","basis":"model_judgment"}'
        else:
            content = "```python\ndef answer():\n    return 42\n```"
        return {"choices": [{"message": {"content": content}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 100, "completion_tokens": 30}}


class APITests(unittest.IsolatedAsyncioTestCase):
    async def test_full_paired_pipeline_and_no_hidden_data_in_requests(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            api = FakeAPI("fake-in-memory-secret", CONFIG, out)
            task = {"id": "TEST", "category": "fake", "prompt": "Implement answer returning 42.",
                    "tests": "assert answer() == 42 # HIDDEN_TEST_MARKER", "reference": "REFERENCE_ONLY_MARKER"}
            await e.run_task(api, task, 1, out)
            rows = [json.loads(p.read_text()) for p in (out / "calls").glob("*.json")]
            result = json.loads((out / "results/TEST_r1.json").read_text())
            self.assertEqual(len(rows), 21)
            self.assertTrue(all(x["grade"]["passed"] for x in result["groups"].values()))
            self.assertEqual(result["groups"]["dualpath"]["metrics"]["physical_calls"], 11)
            self.assertEqual(result["groups"]["self_refine"]["metrics"]["physical_calls"], 11)
            encoded = json.dumps(rows)
            for secret in ("fake-in-memory-secret", "HIDDEN_TEST_MARKER", "REFERENCE_ONLY_MARKER"):
                self.assertNotIn(secret, encoded)
            self.assertAlmostEqual(api.budget.spent, 21 * .00044)
            self.assertAlmostEqual(api.budget.reserved, 0)
            await e.run_task(api, task, 1, out)
            self.assertEqual(len(list((out / "calls").glob("*.json"))), 21)

    async def test_unknown_billing_keeps_full_reservation(self):
        with tempfile.TemporaryDirectory() as tmp:
            api = e.API("fake", CONFIG, Path(tmp))
            def fail(*args):
                raise RuntimeError("simulated network failure")
            api.request = fail
            with self.assertRaises(RuntimeError):
                await api.complete("system", "user", {})
            row = json.loads(next((Path(tmp) / "calls").glob("*.json")).read_text())
            self.assertEqual(row["status"], "error")
            self.assertEqual(api.budget.spent, row["reserved_cny"])
            self.assertAlmostEqual(api.budget.reserved, 0)

    async def test_non_contiguous_call_numbers_do_not_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / "calls").mkdir()
            for number in (1, 3):
                (out / "calls" / f"{number:05d}.json").write_text('{"status":"ok"}')
            api = FakeAPI("fake", CONFIG, out)
            await api.complete("system", "user", {})
            self.assertTrue((out / "calls/00004.json").exists())
            self.assertEqual(json.loads((out / "calls/00003.json").read_text()), {"status": "ok"})


if __name__ == "__main__":
    unittest.main()
