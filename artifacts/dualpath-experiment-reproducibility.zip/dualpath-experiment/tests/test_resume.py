import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))
import experiment as e
import resume as r
from test_experiment import CONFIG, FakeAPI


class RecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_only_missing_condition_is_recomputed(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            api = FakeAPI("fake", CONFIG, out)
            metadata = {"task_id": "TEST", "repeat": 1, "group": "direct", "stage": "[DIRECT_EXECUTE]"}
            initial, initial_record = await api.complete(e.DIRECT_EXECUTE, "user", metadata)
            e.write_json(out / "drafts/TEST_r1.json", {"text": initial, "record": initial_record})
            failed = {"number": 2, "task_id": "TEST", "repeat": 1, "group": "dualpath", "stage": "[ERROR_PROBABILITY]", "status": "error", "cost_peak_cny": .01}
            e.write_json(out / "calls/00002.json", failed)
            api = FakeAPI("fake", CONFIG, out)
            incomplete = {
                "task_id": "TEST",
                "repeat": 1,
                "category": "fake",
                "groups": {
                    "direct": {"output": initial, "metrics": e.metrics([initial_record]), "additional_seconds": 0},
                    "self_refine": {"output": initial, "metrics": e.metrics([initial_record]), "additional_seconds": 1},
                    "dualpath": {"infrastructure_error": "RuntimeError"},
                },
            }
            e.write_json(out / "incomplete/TEST_r1.json", incomplete)
            task = {"id": "TEST", "category": "fake", "prompt": "Implement answer returning 42.", "tests": "assert answer() == 42"}
            before = len(list((out / "calls").glob("*.json")))

            recovered = await r.recover_pair(api, task, 1, out)

            self.assertTrue(recovered)
            self.assertFalse((out / "incomplete/TEST_r1.json").exists())
            result = json.loads((out / "results/TEST_r1.json").read_text())
            self.assertTrue(all(row["grade"]["passed"] for row in result["groups"].values()))
            self.assertTrue(result["groups"]["dualpath"]["recovered_from_infrastructure"])
            self.assertEqual(result["groups"]["self_refine"]["additional_seconds"], 1)
            self.assertEqual(len(list((out / "calls").glob("*.json"))), before + 10)
            self.assertAlmostEqual(result["groups"]["dualpath"]["metrics"]["cost_peak_cny"], initial_record["cost_peak_cny"] + .01 + 10 * .00044)
            await e.run_task(api, task, 1, out)
            self.assertEqual(len(list((out / "calls").glob("*.json"))), before + 10)


if __name__ == "__main__":
    unittest.main()
