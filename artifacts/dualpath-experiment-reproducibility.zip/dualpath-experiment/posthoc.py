"""Clearly post-hoc analyses of existing recordings; no new model requests."""
import json
from audit import RUN, ROOT, cost, content, metrics, read, check, GROUPS
from evaluate import extract_code, grade
import experiment as exp


def main():
    calls = [read(p) for p in sorted((RUN / "calls").glob("*.json"))]
    rows = []
    for task in exp.tasks():
        tid = task["id"]
        task_calls = [c for c in calls if c["task_id"] == tid]
        direct = [c for c in task_calls if c["group"] == "direct"]
        self_calls = [c for c in task_calls if c["group"] == "self_refine"]
        check([c["stage"] for c in self_calls[:2]] == ["[SELF_FEEDBACK]", "[SELF_REWRITE]"], "first round mismatch")
        outcome = grade(extract_code(content(self_calls[1])), task["tests"], timeout=8)
        check(outcome["status"] in {"pass", "fail", "timeout"}, "posthoc grading infrastructure failed")
        rows.append({"task_id": tid, "call_numbers": [c["number"] for c in direct + self_calls[:2]], "grade": outcome, "metrics": metrics(direct + self_calls[:2])})
    cases = {
        "DP005": "try:\n    schedule_tasks([], [('a','b')])\nexcept ValueError:\n    pass\nelse:\n    raise AssertionError('unknown dependency must be rejected')\nassert True\n",
        "DP012": "try:\n    compare_versions('1.2.3\\n', '1.2.3')\nexcept ValueError:\n    pass\nelse:\n    raise AssertionError('terminal newline accepted')\nassert True\n",
        "DP026": "assert schedule_jobs([('a',0,4,['r'])], {'r':[(2,2)]}) == [('a',0,4)]\n",
        "DP029": "try:\n    project_balances([('cancel','x'),('post','x','a',5),('post','x','a',6)])\nexcept ValueError:\n    pass\nelse:\n    raise AssertionError('conflicting canceled posts must raise')\nassert True\n",
    }
    minimal = []
    for tid, test in cases.items():
        result = read(RUN / "results" / f"{tid}_r1.json")
        grades = {g: grade(extract_code(result["groups"][g]["output"]), test) for g in GROUPS}
        check(all(v["status"] in {"pass", "fail"} for v in grades.values()), "minimal case infrastructure failed")
        minimal.append({"task_id": tid, "minimal_test": test, "groups": grades})
    final = {r["task_id"]: r for r in (read(p) for p in (RUN / "results").glob("*.json"))}
    report = {
        "analysis_type": "posthoc_existing_trajectories_not_preregistered",
        "new_model_calls": 0, "first_round": rows,
        "passed": sum(r["grade"]["passed"] for r in rows), "n": len(rows),
        "disagreements_with_five_round": [r["task_id"] for r in rows if r["grade"]["passed"] != final[r["task_id"]]["groups"]["self_refine"]["grade"]["passed"]],
        "mean_cost_estimate_cny": sum(r["metrics"]["cost_estimate_cny"] for r in rows)/len(rows),
        "mean_total_tokens": sum(r["metrics"]["prompt_tokens"]+r["metrics"]["completion_tokens"] for r in rows)/len(rows),
    }
    exp.write_json(ROOT / "audit/first_round_posthoc.json", report)
    exp.write_json(ROOT / "audit/minimal_cases.json", minimal)
    print(json.dumps({k:v for k,v in report.items() if k != "first_round"}, ensure_ascii=False, indent=2))
    print("minimal cases:", {r["task_id"]:{g:v["status"] for g,v in r["groups"].items()} for r in minimal})


if __name__ == "__main__":
    main()
